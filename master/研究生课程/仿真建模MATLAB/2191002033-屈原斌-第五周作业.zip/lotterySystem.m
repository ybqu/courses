function varargout = lotterySystem(varargin)
% LOTTERYSYSTEM MATLAB code for lotterySystem.fig
%      LOTTERYSYSTEM, by itself, creates a new LOTTERYSYSTEM or raises the existing
%      singleton*.
%
%      H = LOTTERYSYSTEM returns the handle to a new LOTTERYSYSTEM or the handle to
%      the existing singleton*.
%
%      LOTTERYSYSTEM('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in LOTTERYSYSTEM.M with the given input arguments.
%
%      LOTTERYSYSTEM('Property','Value',...) creates a new LOTTERYSYSTEM or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before lotterySystem_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to lotterySystem_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help lotterySystem

% Last Modified by GUIDE v2.5 29-Mar-2020 21:11:43

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @lotterySystem_OpeningFcn, ...
                   'gui_OutputFcn',  @lotterySystem_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before lotterySystem is made visible.
function lotterySystem_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to lotterySystem (see VARARGIN)

% Choose default command line output for lotterySystem
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes lotterySystem wait for user response (see UIRESUME)
% uiwait(handles.figure1);

global btype
btype = 1; % Ĭ��˫ɫ��
global bway
bway = 2; % Ĭ�ϻ�ѡ


% --- Outputs from this function are returned to the command line.
function varargout = lotterySystem_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pb_rule.
function pb_rule_Callback(hObject, eventdata, handles)
% hObject    handle to pb_rule (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global btype
title = '��Ϸ����˵��';
if (btype == 1) % ѡ��˫ɫ��
    msg = {'', '�Ӻ�ɫ���1~33��������ѡ��6�����֣�����ɫ���', '1~15��������ѡ��һ�����֣���ͬ���һע���롣', ''};
elseif (btype == 2) % ѡ��3D
    msg = {'', '��000~999����Ȼ����ѡ��һ�����֣���Ϊһע���롣', '', ''};
elseif (btype == 3) % ѡ��31ѡ7
    msg = {'','��01~31����Ȼ����ѡȡ7�����֣���Ϊһע���롣��', 'Ȼ�����һע��Ʊ����͸���淨��', ''};
end
msgbox(msg, title);




function et_bet_count_Callback(hObject, eventdata, handles)
% hObject    handle to et_bet_count (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of et_bet_count as text
%        str2double(get(hObject,'String')) returns contents of et_bet_count as a double


% --- Executes during object creation, after setting all properties.
function et_bet_count_CreateFcn(hObject, eventdata, handles)
% hObject    handle to et_bet_count (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pb_bet.
function pb_bet_Callback(hObject, eventdata, handles)
% hObject    handle to pb_bet (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global bway
global btype

bcount = str2num(get(handles.et_bet_count, 'String'));

if (isempty(bcount) | bcount < 1)  % �ж������Ƿ�Ϊ���ֻ���С��1
    uiwait(msgbox('����������������룡', 'Error','error'));
    set(handles.et_bet_count, 'String', '1');
elseif (bway == 2 & bcount > 5) % ��ѡ��ע��Ϊ1~5
    uiwait(msgbox('��ѡ��ע��Ϊ1~5�����������룡', 'Error','error'));
    set(handles.et_bet_count, 'String', '1');
else
    quest = ['��Ҫ����Ĳ�Ʊע����', num2str(bcount), 'ע��������', num2str(bcount.*2),'Ԫ������ȷ����'];
    is_bet = questdlg(quest, 'ȷ����ע��', 'ȷ����ע', 'ȡ��', 'ȡ��');
    
    if (strcmp(is_bet, 'ȷ����ע'))
        Bet(handles, btype, bway, bcount);
    else
        set(handles.et_bet_count, 'String', '1');
    end
end


function Bet(handles, btype, bway, bcount)
% ��ʾ��Ʊ����
set(handles.et_num_red, 'String', '');
set(handles.et_num_blue, 'String', '');
set(handles.et_num_red, 'ForegroundColor', '#FF0000');
set(handles.et_num_blue, 'ForegroundColor', '#0000FF');
set(handles.et_num_blue, 'enable', 'off');

if (bway == 1) % ��ѡ   
    if (btype == 1) % ˫ɫ��
        numbers = InputNum(bcount);
        set(handles.et_num_blue, 'enable', 'on');
        set(handles.et_num_red, 'String', num2str(numbers(:, 1:6)));
        set(handles.et_num_blue, 'String', num2str(numbers(:, 7)));
    elseif (btype == 2) % 3D
        numbers = InputNum(bcount);
        numbers = numbers(:, 1);
        temp = [];
        for i = 1:bcount
            temp = [temp; sprintf('%03d', numbers(i))];
        end
        set(handles.et_num_red, 'String', temp);
    elseif (btype == 3) % 31ѡ7
        numbers = InputNum(bcount);
        set(handles.et_num_red, 'String', num2str(numbers));
    end
elseif (bway == 2) % ��ѡ
    if (btype == 1) % ˫ɫ��
        set(handles.et_num_blue, 'enable', 'on');
        set(handles.et_num_red, 'String', GenerateNum(bcount, 33, 6));
        set(handles.et_num_blue, 'String', GenerateNum(bcount, 15, 1));
    elseif (btype == 2) % 3D
        numbers = [];
        temp = (randperm(1000, bcount) - 1)';
        for i = 1:bcount
            numbers = [numbers; sprintf('%03d', temp(i))];
        end
        set(handles.et_num_red, 'String', numbers);
    elseif (btype == 3) % 31ѡ7
        set(handles.et_num_red, 'String', GenerateNum(bcount, 31, 7));
    end
end



function numbers = GenerateNum(bcount, max_num, num)
% ���ɲ�Ʊ����
% count -- ע��
% max_num -- ������
% num -- �������
numbers = [];
for i = 1:bcount
    temp = randperm(max_num, num);
    numbers = [numbers; temp];
end
numbers = num2str(numbers);


function numbers = InputNum(bcount)
% �����Ʊ����
 prompt = cell(1, bcount);
definput = cell(1, bcount);
numbers = zeros(bcount, 7);
for i = 1:bcount
    prompt{i} = ['�����', num2str(i), 'ע���룺'];
    definput{i} = '';
end
inputs = inputdlg(prompt, '�����Ʊ����', [1 50], definput);
for i = 1:bcount
        numbers(i, :) = str2num(inputs{i});
end


% --- Executes when selected object is changed in bg_types.
function bg_types_SelectionChangedFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in bg_types 
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global btype
if (hObject == handles.rb_type_ball) % ˫ɫ��
    btype = 1;
elseif (hObject == handles.rb_type_3d) % 3D
    btype = 2;
elseif (hObject == handles.rb_type_31s7) % 31ѡ7
    btype = 3;
end


% --- Executes when selected object is changed in bg_ways.
function bg_ways_SelectionChangedFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in bg_ways 
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global bway
if (hObject == handles.rb_way_optional) % ��ѡ
    bway = 1;
elseif (hObject == handles.rb_way_machine) % ��ѡ
    bway = 2;
end



function et_num_red_Callback(hObject, eventdata, handles)
% hObject    handle to et_num_red (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of et_num_red as text
%        str2double(get(hObject,'String')) returns contents of et_num_red as a double



% --- Executes during object creation, after setting all properties.
function et_num_red_CreateFcn(hObject, eventdata, handles)
% hObject    handle to et_num_red (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function et_num_blue_Callback(hObject, eventdata, handles)
% hObject    handle to et_num_blue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of et_num_blue as text
%        str2double(get(hObject,'String')) returns contents of et_num_blue as a double


% --- Executes during object creation, after setting all properties.
function et_num_blue_CreateFcn(hObject, eventdata, handles)
% hObject    handle to et_num_blue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --------------------------------------------------------------------
function menu_print_Callback(hObject, eventdata, handles)
% hObject    handle to menu_print (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
printpreview;


% --------------------------------------------------------------------
function menu_quit_Callback(hObject, eventdata, handles)
% hObject    handle to menu_quit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

is_quit = questdlg('ȷ���˳�ϵͳ��', '�˳�ϵͳ', 'ȷ��', 'ȡ��', 'ȡ��');

if (strcmp(is_quit, 'ȷ��'))
    close
end


% --- Executes during object creation, after setting all properties.
function figure1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
ha=axes('units','normalized','position',[0 0 1 1]);
uistack(ha,'down')
II=imread('background.jpg');
image(II)
colormap gray
set(ha,'handlevisibility','off','visible','off')
