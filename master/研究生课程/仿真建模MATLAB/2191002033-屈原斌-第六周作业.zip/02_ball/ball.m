function varargout = ball(varargin)
% BALL MATLAB code for ball.fig
%      BALL, by itself, creates a new BALL or raises the existing
%      singleton*.
%
%      H = BALL returns the handle to a new BALL or the handle to
%      the existing singleton*.
%
%      BALL('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in BALL.M with the given input arguments.
%
%      BALL('Property','Value',...) creates a new BALL or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ball_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ball_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ball

% Last Modified by GUIDE v2.5 04-Apr-2020 18:53:27

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ball_OpeningFcn, ...
                   'gui_OutputFcn',  @ball_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ball is made visible.
function ball_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ball (see VARARGIN)

% Choose default command line output for ball
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% ���� y = sin(x) ����
x = linspace(-2*pi,2*pi);
y = sin(x);

plot(x, y);
xticks([-2*pi -3./2*pi -pi -pi./2 0 pi./2 pi 3./2*pi 2*pi]);
xticklabels({'-2\pi', '-3\pi/2', '-\pi', '-\pi/2', '0', '\pi/2', '\pi', '3\pi/2', '2\pi'});

% ����С��
hold on
global g_ball

g_ball = plot(-2*pi, 0, 'or', 'markersize', 10, 'markerfacecolor', 'r');

set(handles.pb_pause, 'string', '��ͣ');
set(handles.pb_pause, 'enable', 'off');
set(handles.pb_stop, 'enable', 'off');

% UIWAIT makes ball wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = ball_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pb_run.
function pb_run_Callback(hObject, eventdata, handles)
% hObject    handle to pb_run (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global g_ball g_stop;

g_stop = 0;

set(handles.pb_pause, 'enable', 'on');
set(handles.pb_stop, 'enable', 'on');

n = 100;
x = linspace(-2*pi,2*pi, n);
y = sin(x);

for i = 2:n
    if g_stop == 1
        break;
    end
    set(g_ball, 'xdata', x(i), 'ydata', y(i));
    drawnow;
end
set(g_ball, 'xdata', -2*pi, 'ydata', 0);



% --- Executes on button press in pb_pause.
function pb_pause_Callback(hObject, eventdata, handles)
% hObject    handle to pb_pause (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

status = get(handles.pb_pause, 'string');
if strcmp(status, '��ͣ')
    set(handles.pb_pause, 'string', '����');
    uiwait;
elseif strcmp(status, '����')
    set(handles.pb_pause, 'string', '��ͣ');
    uiresume;
end


% --- Executes on button press in pb_stop.
function pb_stop_Callback(hObject, eventdata, handles)
% hObject    handle to pb_stop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global g_stop g_ball;
g_stop = 1;

set(g_ball, 'xdata', -2*pi, 'ydata', 0);
set(handles.pb_pause, 'string', '��ͣ');
set(handles.pb_pause, 'enable', 'off');
set(handles.pb_stop, 'enable', 'off');
