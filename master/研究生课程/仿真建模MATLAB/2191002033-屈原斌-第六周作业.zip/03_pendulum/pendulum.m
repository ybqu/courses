function varargout = pendulum(varargin)
% PENDULUM MATLAB code for pendulum.fig
%      PENDULUM, by itself, creates a new PENDULUM or raises the existing
%      singleton*.
%
%      H = PENDULUM returns the handle to a new PENDULUM or the handle to
%      the existing singleton*.
%
%      PENDULUM('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PENDULUM.M with the given input arguments.
%
%      PENDULUM('Property','Value',...) creates a new PENDULUM or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before pendulum_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to pendulum_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help pendulum

% Last Modified by GUIDE v2.5 04-Apr-2020 21:08:06

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @pendulum_OpeningFcn, ...
                   'gui_OutputFcn',  @pendulum_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before pendulum is made visible.
function pendulum_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to pendulum (see VARARGIN)

% Choose default command line output for pendulum
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

global g_ball_size g_ball;

g_ball = [];
g_ball_size = 8;

axis([-150 150 -250 0]);
line([-10 10], [0 0], 'color', 'k', 'linewidth', 5);
set(handles.pb_pause, 'string', '��ͣ');
set(handles.pb_stop, 'string', 'ֹͣ');
set(handles.pb_run, 'enable', 'off');
set(handles.pb_pause, 'enable', 'off');
set(handles.pb_stop, 'enable', 'off');

% UIWAIT makes pendulum wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = pendulum_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function et_angle_Callback(hObject, eventdata, handles)
% hObject    handle to et_angle (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of et_angle as text
%        str2double(get(hObject,'String')) returns contents of et_angle as a double


% --- Executes during object creation, after setting all properties.
function et_angle_CreateFcn(hObject, eventdata, handles)
% hObject    handle to et_angle (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider_angle_Callback(hObject, eventdata, handles)
% hObject    handle to slider_angle (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

value = get(handles.slider_angle, 'value');
set(handles.et_angle, 'string', sprintf('%.2f', value));

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider_angle_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider_angle (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider2_Callback(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider_ball_Callback(hObject, eventdata, handles)
% hObject    handle to slider_ball (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global g_ball g_ball_size;

value = get(handles.slider_ball, 'value');
if ~isempty(g_ball)
    set(g_ball, 'markersize', ceil(value));
end

g_ball_size = ceil(value);

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider_ball_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider_ball (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on button press in pb_cal.
function pb_cal_Callback(hObject, eventdata, handles)
% hObject    handle to pb_cal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global g_ball g_line g_t g_x0 g_y0 g_ball_size; % С�� ���� ���� ��ʼx ��ʼy ��ʼС���С

set(handles.pb_run, 'enable', 'on');

alpha0 = get(handles.et_angle, 'string');
L = get(handles.et_rope, 'string');
alpha0 = str2num(alpha0) / 180 * pi; % ת��Ϊ����
L = str2num(L);

t0 = sqrt(L/9.8);
n = 1000;
alpha = linspace(0, pi/2, n);

% �����
s = 0;
for i = 1:n
    x = 1 - sin(alpha0/2).^2*sin(alpha(i)).^2;
    x = 1 / sqrt(x);
    x = x * (pi/2)/n;
    s = s + x;
end
t = t0*s;
g_t = 4*t;

% ��ʾ�Ӱ�
L = L * 100;
x0 = -1 * L * sin(alpha0);
y0 = -1 * L * cos(alpha0);

hold on
g_line = line([x0, 0], [y0, 0], 'color', 'k', 'linewidth', 2);
g_ball = plot(x0, y0, 'ob', 'markersize', g_ball_size, 'markerfacecolor', 'b');

g_x0 = x0;
g_y0 = y0;


% --- Executes on button press in pb_run.
function pb_run_Callback(hObject, eventdata, handles)
% hObject    handle to pb_run (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global g_ball g_line g_stop g_x0 g_y0;

g_stop = 0;

set(handles.pb_pause, 'enable', 'on');
set(handles.pb_stop, 'enable', 'on');
set(handles.pb_cal, 'enable', 'off');
set(handles.pb_run, 'enable', 'off');
set(handles.slider_angle, 'enable', 'off');
set(handles.slider_rope, 'enable', 'off');

L = get(handles.et_rope, 'string');
L = str2num(L) * 100;

n = 50;
x = linspace(g_x0, -g_x0, n);
y = -1 * sqrt(L.^2 - x.^2);

while (1)
    for i = 1:n
        if g_stop == 1
            break
        end
        set(g_ball, 'xdata', x(i), 'ydata', y(i));
        set(g_line, 'xdata', [0 x(i)], 'ydata', [0 y(i)]);
        drawnow;
    end
    for i = n-1:-1:1
        if g_stop == 1
            break
        end
        set(g_ball, 'xdata', x(i), 'ydata', y(i));
        set(g_line, 'xdata', [0 x(i)], 'ydata', [0 y(i)]);
        drawnow;
    end
    if g_stop == 1
        break
    end
end

set(g_ball, 'xdata', g_x0, 'ydata', g_y0);
set(g_line, 'xdata', [g_x0 0], 'ydata', [g_y0 0]);


% --- Executes on button press in pb_pause.
function pb_pause_Callback(hObject, eventdata, handles)
% hObject    handle to pb_pause (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

is_pause = get(handles.pb_pause, 'string');
if strcmp(is_pause, '��ͣ')
    set(handles.pb_pause, 'string', '����');
    uiwait;
elseif strcmp(is_pause, '����')
    set(handles.pb_pause, 'string', '��ͣ');
    uiresume;
end


% --- Executes on button press in pb_stop.
function pb_stop_Callback(hObject, eventdata, handles)
% hObject    handle to pb_stop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global g_stop g_ball;

is_stop = get(handles.pb_stop, 'string');

if strcmp(is_stop, 'ֹͣ')
    g_stop = 1;
    set(handles.pb_stop, 'string', '���');
elseif strcmp(is_stop, '���')
    cla;
    line([-10 10], [0 0], 'color', 'k', 'linewidth', 5);
    set(handles.pb_stop, 'string', 'ֹͣ');
    set(handles.pb_cal, 'enable', 'on');
    set(handles.pb_run, 'enable', 'off');
    set(handles.pb_pause, 'enable', 'off');
    set(handles.pb_stop, 'enable', 'off');
    set(handles.slider_angle, 'enable', 'on');
    set(handles.slider_rope, 'enable', 'on');
    g_ball = [];
end


% --- Executes on slider movement.
function slider3_Callback(hObject, eventdata, handles)
% hObject    handle to slider3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function slider_rope_Callback(hObject, eventdata, handles)
% hObject    handle to slider_rope (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

value = get(handles.slider_rope, 'value');
set(handles.et_rope, 'string', sprintf('%.2f', value));
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider_rope_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider_rope (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function et_rope_Callback(hObject, eventdata, handles)
% hObject    handle to et_rope (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of et_rope as text
%        str2double(get(hObject,'String')) returns contents of et_rope as a double


% --- Executes during object creation, after setting all properties.
function et_rope_CreateFcn(hObject, eventdata, handles)
% hObject    handle to et_rope (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
