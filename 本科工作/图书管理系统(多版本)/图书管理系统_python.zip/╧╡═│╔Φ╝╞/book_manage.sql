-- phpMyAdmin SQL Dump
-- version 4.4.15.10
-- https://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 2019-12-10 14:54:58
-- 服务器版本： 5.7.27-log
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `book_manage`
--

-- --------------------------------------------------------

--
-- 表的结构 `auth_group`
--

CREATE TABLE IF NOT EXISTS `auth_group` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `auth_group_permissions`
--

CREATE TABLE IF NOT EXISTS `auth_group_permissions` (
  `id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `auth_permission`
--

CREATE TABLE IF NOT EXISTS `auth_permission` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can view log entry', 1, 'view_logentry'),
(5, 'Can add permission', 2, 'add_permission'),
(6, 'Can change permission', 2, 'change_permission'),
(7, 'Can delete permission', 2, 'delete_permission'),
(8, 'Can view permission', 2, 'view_permission'),
(9, 'Can add group', 3, 'add_group'),
(10, 'Can change group', 3, 'change_group'),
(11, 'Can delete group', 3, 'delete_group'),
(12, 'Can view group', 3, 'view_group'),
(13, 'Can add user', 4, 'add_user'),
(14, 'Can change user', 4, 'change_user'),
(15, 'Can delete user', 4, 'delete_user'),
(16, 'Can view user', 4, 'view_user'),
(17, 'Can add content type', 5, 'add_contenttype'),
(18, 'Can change content type', 5, 'change_contenttype'),
(19, 'Can delete content type', 5, 'delete_contenttype'),
(20, 'Can view content type', 5, 'view_contenttype'),
(21, 'Can add session', 6, 'add_session'),
(22, 'Can change session', 6, 'change_session'),
(23, 'Can delete session', 6, 'delete_session'),
(24, 'Can view session', 6, 'view_session'),
(25, 'Can add bm book', 7, 'add_bmbook'),
(26, 'Can change bm book', 7, 'change_bmbook'),
(27, 'Can delete bm book', 7, 'delete_bmbook'),
(28, 'Can view bm book', 7, 'view_bmbook'),
(29, 'Can add bm borrow', 8, 'add_bmborrow'),
(30, 'Can change bm borrow', 8, 'change_bmborrow'),
(31, 'Can delete bm borrow', 8, 'delete_bmborrow'),
(32, 'Can view bm borrow', 8, 'view_bmborrow'),
(33, 'Can add bm reservation', 9, 'add_bmreservation'),
(34, 'Can change bm reservation', 9, 'change_bmreservation'),
(35, 'Can delete bm reservation', 9, 'delete_bmreservation'),
(36, 'Can view bm reservation', 9, 'view_bmreservation'),
(37, 'Can add bm comment', 10, 'add_bmcomment'),
(38, 'Can change bm comment', 10, 'change_bmcomment'),
(39, 'Can delete bm comment', 10, 'delete_bmcomment'),
(40, 'Can view bm comment', 10, 'view_bmcomment'),
(41, 'Can add bm manager', 11, 'add_bmmanager'),
(42, 'Can change bm manager', 11, 'change_bmmanager'),
(43, 'Can delete bm manager', 11, 'delete_bmmanager'),
(44, 'Can view bm manager', 11, 'view_bmmanager'),
(45, 'Can add bm student', 12, 'add_bmstudent'),
(46, 'Can change bm student', 12, 'change_bmstudent'),
(47, 'Can delete bm student', 12, 'delete_bmstudent'),
(48, 'Can view bm student', 12, 'view_bmstudent');

-- --------------------------------------------------------

--
-- 表的结构 `auth_user`
--

CREATE TABLE IF NOT EXISTS `auth_user` (
  `id` int(11) NOT NULL,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `auth_user_groups`
--

CREATE TABLE IF NOT EXISTS `auth_user_groups` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `auth_user_user_permissions`
--

CREATE TABLE IF NOT EXISTS `auth_user_user_permissions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `bm_book`
--

CREATE TABLE IF NOT EXISTS `bm_book` (
  `no` char(6) NOT NULL COMMENT '编号',
  `title` varchar(255) NOT NULL COMMENT '书名',
  `author` varchar(255) NOT NULL COMMENT '作者',
  `publisher` varchar(255) NOT NULL COMMENT '出版社',
  `p_date` date NOT NULL COMMENT '出版日期',
  `inventory` int(10) NOT NULL COMMENT '总库存',
  `lend_num` int(10) NOT NULL DEFAULT '0' COMMENT '已借出',
  `borrow_num` int(10) NOT NULL DEFAULT '0' COMMENT '借阅次数'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='图书信息表';

--
-- 转存表中的数据 `bm_book`
--

INSERT INTO `bm_book` (`no`, `title`, `author`, `publisher`, `p_date`, `inventory`, `lend_num`, `borrow_num`) VALUES
('F120', '科学计算导论', '按时的', '清华大学出版社', '2012-01-19', 2, 0, 2),
('F121', '嵌入式实时操作系统ucos-II', '方法他', '航空航天大学出版社', '2012-03-19', 1, 1, 92),
('F122', '嵌入式系统设计与实践', '好看', '航空航天大学出版社', '2012-01-19', 2, 1, 61),
('F123', '嵌入式系统设计与应用开发', '由于与', '航空航天大学出版社', '2011-07-19', 2, 2, 34),
('F124', '人工神经网络与模拟进化计算', '下风格', '清华大学出版社', '2012-01-19', 2, 1, 29),
('F125', '数据结构——Java语言描述', '饿额', '清华大学出版社', '2012-05-19', 2, 1, 46),
('F126', '数据库原理', '共同', '清华大学出版社', '2012-01-19', 1, 0, 17),
('G543', '数据挖掘实用机器学习技术', '天天', '机械工业出版社', '2012-02-19', 3, 2, 78),
('G544', '无线网络原理', '明明内', '科学出版社', '2012-01-19', 2, 0, 76),
('G545', '语义网简明教程', '仆仆和', '高等教育出版社', '2012-09-19', 2, 2, 97),
('G546', '语义信息模型及应用', '自治州', '电子工业出版社', '2012-01-19', 2, 1, 20),
('G547', '智能Agent及在网络中的应用', '彻底', '邮电大学出版社', '2012-08-19', 2, 0, 45),
('TP302', 'Ajax基础教程', '事实上', '人民邮电出版社', '1980-06-05', 3, 0, 36),
('TP304', 'Ajax开发精要--概念案例与框架', '艰苦派', '电子工业出版社', '1995-04-02', 3, 0, 60),
('TP305', 'Ajax修炼之道--Web入门', '哦批评', '电子工业出版社', '2005-07-01', 1, 0, 70),
('TP306', 'ARM嵌入式系统实验教程(二)', '往往外', '航空航天大学出版社', '1993-08-20', 2, 0, 79),
('TP307', 'ARM嵌入式系统实验教程(三)', '亲切', '航空航天大学出版社', '2007-05-03', 1, 0, 39),
('TP308', 'ARM体系结构与编程', '白不能', '清华大学出版社', '2009-07-10', 1, 0, 54),
('TP309', 'ARM微控制器基础与实战', '仍然如', '航空航天大学出版社', '2013-10-03', 2, -1, 63),
('TP310', 'ASP.NET开发指南', '谈话感', '人民邮电出版社', '2010-08-25', 1, 1, 94),
('TP311', 'J2ME开发精解', '督导', '电子工业出版社', '2008-05-09', 1, 0, 75),
('TP312', '多智能体模型与实验', '饿额', '清华大学出版社', '2012-07-19', 1, 0, 36),
('TP313', '关于知识的本体论研究', '如同眼', '巴蜀书社', '2013-01-19', 1, 0, 78),
('TP314', '机器学习及其应用', '轧花机', '清华大学出版社', '2012-01-19', 1, 0, 75),
('TP315', '基于MATLAB的系统分析与设计', '搞活机', '西安电子科技大学', '2012-01-19', 1, 0, 13),
('TP316', '计算机语料库的建设与应用', '飞过海', '清华大学出版社', '1991-01-19', 1, 1, 99),
('TP317', '计算语言学前瞻', '各个', '商务印书馆', '2012-01-19', 1, 0, 12),
('XW3001', '中国历代文学作品选', '朱东润', '人民文学出版社', '1962-03-07', 3, 1, 22),
('XW3002', '中国文学史', '章培恒、骆玉明', '上海文艺出版社', '2000-04-08', 2, 1, 9),
('XW3003', '中国古代文学史', '郭预衡', '上海古籍出版社', '1998-05-09', 4, 0, 61),
('XW3004', '中国分体文学史', '李修生、赵义山', '上海古籍出版社', '2000-06-06', 2, 1, 88),
('XW3005', '中国散文发展史', '张梦新', '杭州大学出版社', '1996-07-11', 3, 0, 47),
('XW3006', '中国传记文学发展史', '陈兰村', '语文出版社', '1999-01-12', 5, 0, 0),
('XW3007', '中国诗史', '陆侃如、冯沅君', '人发文学出版社', '1983-09-13', 3, 0, 21),
('XW3008', '中国诗史', '日吉川幸次郎', '安徽文艺出版社', '1986-10-04', 2, 0, 90),
('XW3009', '中国诗话史', '蔡镇楚', '湖南文艺出版社', '1988-06-15', 4, 0, 38),
('XW3010', '中国古典小说史论', '杨义', '人民出版社', '1998-12-16', 2, 0, 53),
('XW3011', '中国古典小说史论', '美夏志清', '江西人民出版社', '2001-10-02', 3, 0, 72),
('XW3012', '中国小说史学史长编', '胡从经', '上海文艺出版社', '1998-07-18', 5, 0, 100),
('XW3013', '中国戏曲通史', '张庚、郭汉城', '中国戏曲出版社', '1987-09-01', 3, 0, 93),
('XW3014', '中国古典文学研究史', '郭英德等', '中华书局', '1995-03-20', 2, 0, 50),
('XW3015', '中国主平点文学史', '孙琴安', '上海社会科学院出版社', '1999-03-07', 4, 0, 72),
('XW3016', '中国古典诗歌接受史研究', '陈文忠', '安徽大学出版社', '1998-04-08', 2, 0, 58),
('XW3027', '庄骚传播接受史综论', '尚永亮', '文化艺术出版社', '2000-05-09', 3, 0, 69),
('XW3030', '中古文学史论著', '王瑶', '上海古籍出版社', '1982-06-06', 5, 0, 87),
('XW3031', '唐五代文学编年史', '傅璇琮', '辽宁教育出版社', '2000-07-11', 3, 0, 79),
('XW3032', '宋元戏曲史', '王国维', '华东师范大学出版社', '1995-01-12', 2, 0, 41),
('XW3033', '明代小说史', '陈大康', '上海文艺出版社', '2000-09-13', 4, 0, 12),
('XW3034', '中国诗学体系论', '陈良运', '中国社会科学出版社', '1992-10-04', 2, 1, 100),
('XW3035', '中国古代接受诗学', '邓新华', '武汉大学出版社', '2000-06-15', 3, 0, 95),
('XW3036', '中国叙事学', '杨义', '人民出版社', '1998-01-16', 5, 0, 75),
('XW3037', '中国小说叙事模式的转变', '陈平原', '上海人民出版社', '1988-10-02', 3, 0, 10),
('XW3038', '中国的神话世界', '王孝廉（台湾）', '作家出版社', '1991-07-18', 2, 1, 4),
('XW3039', '中国神话论文选萃（上下）', '马昌仪', '中国广播电视出版社', '1994-09-01', 4, 2, 37),
('XW3040', '中国神话哲学', '叶舒宪', '中国社会科学出版社', '1992-03-20', 2, 0, 4),
('XW3041', '先秦叙事研究', '傅延修', '东方出版社', '1999-03-28', 3, 0, 83),
('XW3132', '周易与中国文学', '陈良运', '百花洲文艺出版社', '1999-04-29', 5, 0, 39),
('XW3133', '诗经的文化阐释', '叶舒宪', '湖北人民出版社', '1994-05-27', 3, 0, 8),
('XW3134', '诗经与周代社会研究', '孙作云', '中华书局', '1966-06-07', 2, 0, 66),
('XW3135', '魏晋玄学新论', '徐斌', '上海古籍出版社', '2000-07-08', 4, 0, 87),
('XW3136', '门阀士族与永明文学', '刘跃进', '三联书店', '1996-01-09', 2, 1, 44),
('XW3137', '唐诗学引论', '陈伯海', '东方出版中心', '1996-09-06', 3, 0, 28),
('XW3138', '盛唐文学的文化透视', '霍松林、傅绍良', '陕西师范大学出版社', '2000-10-11', 5, 1, 92),
('XW3139', '大历诗人研究', '蒋寅', '中华书局', '1995-06-12', 3, 0, 38),
('XW3140', '唐宋词通话', '吴熊和', '浙江古籍出版社', '1985-03-13', 2, 0, 71),
('XW3141', '宋代词学的审美理想', '张惠民', '人民文学出版社', '1995-02-04', 4, 0, 89);

-- --------------------------------------------------------

--
-- 表的结构 `bm_borrow`
--

CREATE TABLE IF NOT EXISTS `bm_borrow` (
  `id` int(10) NOT NULL,
  `stu_no` char(10) NOT NULL COMMENT '学号',
  `book_no` char(6) NOT NULL COMMENT '图书编号',
  `borrow_date` datetime NOT NULL COMMENT '借阅日期',
  `deadline` datetime NOT NULL COMMENT '应还日期',
  `return_date` datetime DEFAULT NULL COMMENT '归还日期',
  `is_return` tinyint(1) NOT NULL DEFAULT '0' COMMENT '归还状态',
  `is_renewal` tinyint(1) NOT NULL DEFAULT '0' COMMENT '续借状态'
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COMMENT='借阅信息记录表';

--
-- 转存表中的数据 `bm_borrow`
--

INSERT INTO `bm_borrow` (`id`, `stu_no`, `book_no`, `borrow_date`, `deadline`, `return_date`, `is_return`, `is_renewal`) VALUES
(1, '1113000001', 'F124', '2019-11-30 15:59:17', '2020-01-29 15:59:17', '2019-11-30 15:59:33', 1, 0),
(2, '1234567890', 'TP309', '2019-12-03 03:31:30', '2020-02-01 03:31:30', '2019-12-09 12:42:57', 1, 0),
(3, '1234567890', 'F120', '2019-12-03 03:31:53', '2020-01-02 03:31:53', '2019-12-03 03:32:09', 1, 0),
(4, '1234567890', 'TP316', '2019-12-03 03:32:00', '2020-01-02 03:32:00', '2019-12-03 06:59:02', 1, 0),
(5, '1234567890', 'F122', '2019-12-03 03:32:33', '2020-02-01 03:32:33', '2019-12-09 12:36:11', 1, 0),
(6, '1234567890', 'TP308', '2019-12-03 03:32:50', '2020-01-02 03:32:50', '2019-12-03 13:22:11', 1, 0),
(7, '1113000002', 'XW3012', '2019-12-03 06:55:51', '2020-01-02 06:55:51', '2019-12-03 06:56:37', 1, 0),
(8, '1113000002', 'XW3034', '2019-12-03 06:56:16', '2020-01-02 06:56:16', NULL, 0, 0),
(9, '1113000002', 'G545', '2019-12-03 06:56:27', '2020-01-02 06:56:27', NULL, 0, 0),
(10, '1113000002', 'G546', '2019-12-03 06:57:21', '2020-01-02 06:57:21', NULL, 0, 0),
(11, '1113000002', 'G543', '2019-12-03 06:58:18', '2020-01-02 06:58:18', NULL, 0, 0),
(12, '1234567890', 'F120', '2019-12-03 06:59:45', '2020-01-02 06:59:45', '2019-12-09 12:36:18', 1, 0),
(13, '1234567890', 'TP308', '2019-12-03 13:23:06', '2020-01-02 13:23:06', '2019-12-03 13:23:40', 1, 0),
(14, '1234567890', 'TP316', '2019-12-09 12:37:13', '2020-02-07 12:37:13', NULL, 0, 1);

-- --------------------------------------------------------

--
-- 表的结构 `bm_comment`
--

CREATE TABLE IF NOT EXISTS `bm_comment` (
  `id` int(10) NOT NULL,
  `stu_no` char(10) NOT NULL COMMENT '学号',
  `book_no` char(6) NOT NULL COMMENT '图书编号',
  `content` varchar(255) NOT NULL COMMENT '评论内容',
  `score` decimal(2,1) NOT NULL DEFAULT '0.0' COMMENT '评分',
  `date` datetime NOT NULL COMMENT '评论日期'
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='图书评论表';

--
-- 转存表中的数据 `bm_comment`
--

INSERT INTO `bm_comment` (`id`, `stu_no`, `book_no`, `content`, `score`, `date`) VALUES
(1, '1113000001', 'F124', '很好', '4.5', '2019-11-30 15:59:41'),
(2, '1234567890', 'F120', '非常棒！', '5.0', '2019-12-03 03:32:17'),
(3, '1113000002', 'XW3012', '1', '0.5', '2019-12-03 06:56:45'),
(4, '1234567890', 'TP316', 'very good', '5.0', '2019-12-03 06:59:15'),
(5, '1234567890', 'TP308', '11212121212', '4.5', '2019-12-03 13:22:21'),
(6, '1234567890', 'TP309', '受益很多', '5.0', '2019-12-09 12:44:02');

-- --------------------------------------------------------

--
-- 表的结构 `bm_manager`
--

CREATE TABLE IF NOT EXISTS `bm_manager` (
  `id` int(10) NOT NULL COMMENT 'id',
  `username` varchar(20) NOT NULL COMMENT '用户名',
  `name` varchar(255) NOT NULL COMMENT '姓名',
  `password` varchar(255) NOT NULL COMMENT '密码',
  `role` tinyint(1) NOT NULL COMMENT '角色'
) ENGINE=InnoDB AUTO_INCREMENT=254 DEFAULT CHARSET=utf8 COMMENT='管理员信息表';

--
-- 转存表中的数据 `bm_manager`
--

INSERT INTO `bm_manager` (`id`, `username`, `name`, `password`, `role`) VALUES
(243, 'atKsOption', '午康俊', 'pbkdf2_sha256$150000$AIdeuejbaU8g$Pdr4AtN+9n/KR0tgY2CjMuUZRLArmilChcUwY4WNawY=', 0),
(244, 'wukangjun', '东契奇', 'pbkdf2_sha256$180000$ke35eG5VZznu$OXpryxgVZsKgnE75ttTmSXvaCPl3s33ZkDaTCatYtuY=', 1),
(245, 'HarryPotter', '哈利波特', 'pbkdf2_sha256$180000$iaDuxSpxk9N3$7Aa2N4lPqsGML5DMfnDJPl7kBPl8Zu4pfi4btZKWPEQ=', 2),
(249, 'quxiansen', '屈原斌', 'pbkdf2_sha256$150000$K88MV7cMvPhz$yl4LVe5J3X2TnhC/spg5wXKwRRscpRI2lxVAaWiZeNM=', 0);

-- --------------------------------------------------------

--
-- 表的结构 `bm_reservation`
--

CREATE TABLE IF NOT EXISTS `bm_reservation` (
  `id` int(10) NOT NULL,
  `stu_no` char(10) NOT NULL COMMENT '学号',
  `book_no` char(6) NOT NULL COMMENT '图书编号',
  `date` datetime NOT NULL COMMENT '预约日期'
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COMMENT='图书预约表';

-- --------------------------------------------------------

--
-- 表的结构 `bm_student`
--

CREATE TABLE IF NOT EXISTS `bm_student` (
  `no` char(10) NOT NULL COMMENT '学号',
  `password` varchar(255) NOT NULL COMMENT '密码',
  `name` varchar(255) NOT NULL COMMENT '姓名',
  `class` varchar(255) NOT NULL COMMENT '班级',
  `major` varchar(255) NOT NULL COMMENT '专业',
  `contact` char(11) NOT NULL COMMENT '联系方式'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='学生信息表';

--
-- 转存表中的数据 `bm_student`
--

INSERT INTO `bm_student` (`no`, `password`, `name`, `class`, `major`, `contact`) VALUES
('1113000001', 'pbkdf2_sha256$180000$LPmGbw33AjTY$ZANzXViXuOLWSR/XV8LGdZXdUjYS+5nq3dhPBNbxxnA=', '陈123', 'cj11B10ms', '美术学', '13146385999'),
('1113000002', 'pbkdf2_sha256$180000$R2lNMI9X18Gg$U2v7KCqhmzkANSk77AB0m/iAcsCACHDBZ7wWsdfE/Yg=', '陈梧宾', 'cj11B10ms', '美术学', '13381118748'),
('1113000003', 'pbkdf2_sha256$180000$j0j3XpP4sAbB$BPn72+GhpFxkikQXjhNc+O6I6tsMcFzH7DvsLRLpi4E=', '仇宇宁', 'cj11B10ms', '美术学', '15811489199'),
('1113000004', 'pbkdf2_sha256$180000$xEUZcRkhxuWl$l7xmpqnZ56WYdHcyqQIOBCsdugoKkMVlFKu8aNnlXzI=', '崔子健', 'cj11B10ms', '美术学', '13597785145'),
('1113000005', 'pbkdf2_sha256$180000$UksCeIWXsoY6$Rfz6y0MT03ZSCMS8XDHygF22DSQJaBt9QTyKW6noNek=', '范欣然', 'cj11B10ms', '美术学', '13717987157'),
('1210900010', 'pbkdf2_sha256$180000$oaJQZxIxtgSS$av4auU9Lbbo9hC9Tzsnrx287lR0cyQSALKlSNcJ9WaY=', '顾伟利', 'dl11B1sf', '地理科学', '15794511983'),
('1210900011', 'pbkdf2_sha256$180000$5jLqBlmj6gKh$fIzlQrQWOHAaeG7I2/6DjgWv0OUgrOLi8gEdMX3Z1ec=', '郭晨绪', 'dl11B1sf', '地理科学', '15336955973'),
('1210900012', 'pbkdf2_sha256$180000$ZyAHQHeWP6Kk$JcVqgqF5XxQcAVAdQgbzxm6ol9tVc7sUksuIbXjdr3o=', '侯艺菲', 'dl11B1sf', '地理科学', '13941698396'),
('1210900013', 'pbkdf2_sha256$180000$Gt9k33UyzP7o$z3W1BZVKXKsfdy0mQ9cwvt6enbAofvatn5GV4r0InTw=', '胡佳媛', 'dl11B1sf', '地理科学', '15339734979'),
('1210900014', 'pbkdf2_sha256$180000$4dDVbgZbWpbe$zPq+K8f4xrSsSJXcL2e/zlr3KN6wVrf8U9dpmaSfEFs=', '姜霖', 'dl11B1sf', '地理科学', '13391887894'),
('1211000020', 'pbkdf2_sha256$180000$bFXfwfixUn2X$Z00FF5ZjksWZh1CTpLnJfERFZQhoew36KFj3PvTr9F8=', '丁梦美', 'xg11B1B', '计算机科学与技术', '18779669937'),
('1211000021', 'pbkdf2_sha256$180000$T2HZ4Pq4EvPA$c5Stp6QTqqYIDyA4VX2Kx/7KO0AKx9IUuKvqF1YvXTA=', '葛娜', 'xg11B1B', '计算机科学与技术', '15611793359'),
('1211000022', 'pbkdf2_sha256$180000$txlYq1GSI8pV$7k7+4FB4QUKen47kOcQ69O/UXrk8bQn61yw9IJVP9is=', '李佳伯男', 'xg11B1B', '计算机科学与技术', '13971979978'),
('1211000023', 'pbkdf2_sha256$180000$1zU4Nl6AS2gZ$okLreYCGOGt0bupBm4jPwwZ2LTyQ52qldl3lVmbsrM4=', '李晴', 'xg11B1B', '计算机科学与技术', '13716875166'),
('1211000024', 'pbkdf2_sha256$180000$NPLYOL8gfXNv$uY2gGW1Ecjx3aJ6Bhwj+dODcL4C4nF012iHEQf/63zU=', '林浩然', 'xg11B1B', '计算机科学与技术', '13955936934'),
('1211000025', 'pbkdf2_sha256$180000$uTZRMyR1uRf0$21l7JlIl4xMQZKaoKTpGiQ1jlNWVTPuL+0YaNLeXC+s=', '娄欣', 'xg11B1B', '计算机科学与技术', '13969449887'),
('1211000026', 'pbkdf2_sha256$180000$8sfFVJwHFkfo$VqP0VtCnJyslUA4XgT/UIUnWNpW8oFr30o9Jjrx4cPg=', '马杨', 'xg11B1B', '计算机科学与技术', '18797716767'),
('1211000027', 'pbkdf2_sha256$180000$Jw4SwQxLlSAw$+9TJlLBSug2aqww0RrIc/8mE3BWt+XxDK5UkOznoFHg=', '马洋', 'xg11B1B', '计算机科学与技术', '15711364617'),
('1211000028', 'pbkdf2_sha256$180000$WGai2rBC1GY4$Cx4miJZOq4AsYUVEpPt3eXn2mof/np0IbAQGL1qpxiw=', '王璐瑶', 'xg11B1B', '计算机科学与技术', '13716456917'),
('1211000029', 'pbkdf2_sha256$180000$PenZxd3pggr1$5Ia8Pb9UrFj/xE05K7nQ4qLlSxadZJ4iCDrmSb83kmI=', '魏雪霏', 'xg11B1B', '计算机科学与技术', '13611878157'),
('1213000006', 'pbkdf2_sha256$180000$Yf610BGbbQiZ$CNLarZ1zP6HYXqYNE2csyiuA0CLPxoHyXSiUbieFzTw=', '高岩艳', 'cj11B10ms', '美术学', '15871995781'),
('1213000007', 'pbkdf2_sha256$180000$ufHK66aIRWTK$KfNQXChsIeqS8wGDHeHpSj3Vj3SfDG+nxLwkqugrKZo=', '李鑫', 'cj11B10ms', '美术学', '13651759894'),
('1213000008', 'pbkdf2_sha256$180000$4MpUO1Gw3iGN$Vrxz09VnsORohapSdV3eX3eDDE19TyyMKnb4GxtDP2E=', '马凤齐', 'cj11B10ms', '美术学', '13597776384'),
('1213000009', 'pbkdf2_sha256$180000$AuY7W3HZ2Dua$tl+7iWxIoZ5QEAoiYATONrxunJSEqwtnnrs0Si3iIN4=', '马俊杰', 'cj11B10ms', '美术学', '15711976618'),
('1213000010', 'pbkdf2_sha256$180000$XmF5Yi3B0zQN$zWad48GTz21l90+XVORk/4IoDvPckxA5TbBA1akdSJE=', '彭振', 'cj11B10ms', '美术学', '13969188951'),
('1234567890', 'pbkdf2_sha256$180000$oiTwQMoXcpFk$2KaHwlDrvSvuRD/lCU1/W/oozhh7c9MK3OdamcqzvSE=', 'wuknagjun', 'C01', 'ruanjiangongcheng', '13123454567'),
('1310900015', 'pbkdf2_sha256$180000$vN1ewHv79iOV$cwajdEgFpMafTAc/0f+AefO5uMLcKLmhx9nVW6h+xBQ=', '李闻天', 'dl11B1sf', '地理科学', '15917798361'),
('1310900016', 'pbkdf2_sha256$180000$baqTeyfnaQoK$ITe3EJuYJRwBUU5s5cAWe/rLkMRX0w0qdFhvguKTSnQ=', '李亚凯', 'dl11B1sf', '地理科学', '13611977778'),
('1310900017', 'pbkdf2_sha256$180000$XQD0jPWl6VcJ$aoDqSZbvofYHJCGPPm+z1639chFnttFtroCK5y/3rDY=', '李哲', 'dl11B1sf', '地理科学', '15745949771'),
('1310900018', 'pbkdf2_sha256$180000$N9p7HscFNlyI$wuzDb6M3M6r0UVpWZcSoYRzL4e+QiWv01WD+Tb8CtXI=', '刘敏', 'dl11B1sf', '地理科学', '18254696196'),
('1310900019', 'pbkdf2_sha256$180000$dN5fyLLjHiDx$gUIu0NA/zP6mcz/0MYRzNIuioAi1CnoM/qFwzHDhMxU=', '刘涛', 'dl11B1sf', '地理科学', '15504496245'),
('1412021021', 'pbkdf2_sha256$180000$PYIuJ0rU8AU5$wvd8MUxdE2Tpf5wvb19KPeZ7+5Dtbx4wC9ek/Hu1F7c=', '赵月', 'wy11B1ry', '英语', '13559799498'),
('1412021022', 'pbkdf2_sha256$180000$jyHpzNJJ5RY0$Nak0QVGY8/b+7hewc6hzn8sqiCTQ87c2X7HWj1bObjE=', '赵震天', 'wy11B1ry', '英语', '13552548968'),
('1412021023', 'pbkdf2_sha256$180000$P5M6WW6yrgWL$s6BegeQjSKAUHt9YU/0xv/r66lzKeN+M+HOUQV1RkSU=', '安琪', 'wy11B1xy', '英语', '13131168978'),
('1412021024', 'pbkdf2_sha256$180000$FnLhUW2qfwzJ$qJjlopTlT3ZMctvxHJMpnsP0zvFlYSn/as1OynYgMa8=', '郝一伟', 'wy11B1xy', '英语', '13611719331'),
('1412021025', 'pbkdf2_sha256$180000$V0PWKY1Nbnue$5WizJV3oWgZTYVgNIYiN4ptWCm2BTV38UL5aBqqgg7Q=', '姜楠', 'wy11B1xy', '英语', '13591397684'),
('1412021026', 'pbkdf2_sha256$180000$ZIAo7yf678mB$VMBAt96J/x/eW3QaLl2oOifXMSsDbWPc0Go8p6aR5+Y=', '李梦阳', 'wy11B1xy', '英语', '15971339795'),
('1412021027', 'pbkdf2_sha256$180000$MhjktQwbNSfc$RzvUXIFDXlT1meWPotRM1s+Ow2xEz0XnP0ObI721kkw=', '孟明瑞', 'wy11B1xy', '英语', '15537158569'),
('1412021028', 'pbkdf2_sha256$180000$cOGibCYlbWWT$3yQOxT6LL7VesxM3CMgb6z1A4FY9Q5buNPaKT7LZ8n8=', '孟祥雪', 'wy11B1xy', '英语', '15517571891'),
('1412021029', 'pbkdf2_sha256$180000$YwG6yLvjfjDl$C8CPE/ednxGYYZYWA2UwuSCPSZIGtA2vytuyOsY7078=', '孟宜霏', 'wy11B1xy', '英语', '13651957989'),
('1412021030', 'pbkdf2_sha256$180000$kB6TL1CYTmR2$ZxbpOzp4DT0Su6BEbPena631BptxbmoSFrQfhPbVPHM=', '乔俊姣', 'wy11B1xy', '英语', '13598763875');

-- --------------------------------------------------------

--
-- 表的结构 `django_admin_log`
--

CREATE TABLE IF NOT EXISTS `django_admin_log` (
  `id` int(11) NOT NULL,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `django_content_type`
--

CREATE TABLE IF NOT EXISTS `django_content_type` (
  `id` int(11) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(3, 'auth', 'group'),
(2, 'auth', 'permission'),
(4, 'auth', 'user'),
(7, 'books', 'bmbook'),
(8, 'borrows', 'bmborrow'),
(9, 'borrows', 'bmreservation'),
(10, 'comments', 'bmcomment'),
(5, 'contenttypes', 'contenttype'),
(11, 'managers', 'bmmanager'),
(6, 'sessions', 'session'),
(12, 'students', 'bmstudent');

-- --------------------------------------------------------

--
-- 表的结构 `django_migrations`
--

CREATE TABLE IF NOT EXISTS `django_migrations` (
  `id` int(11) NOT NULL,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2019-11-25 06:18:50.603675'),
(2, 'auth', '0001_initial', '2019-11-25 06:18:50.909463'),
(3, 'admin', '0001_initial', '2019-11-25 06:18:51.398972'),
(4, 'admin', '0002_logentry_remove_auto_add', '2019-11-25 06:18:51.539432'),
(5, 'admin', '0003_logentry_add_action_flag_choices', '2019-11-25 06:18:51.561302'),
(6, 'contenttypes', '0002_remove_content_type_name', '2019-11-25 06:18:51.682850'),
(7, 'auth', '0002_alter_permission_name_max_length', '2019-11-25 06:18:51.736491'),
(8, 'auth', '0003_alter_user_email_max_length', '2019-11-25 06:18:51.793119'),
(9, 'auth', '0004_alter_user_username_opts', '2019-11-25 06:18:51.814055'),
(10, 'auth', '0005_alter_user_last_login_null', '2019-11-25 06:18:51.870841'),
(11, 'auth', '0006_require_contenttypes_0002', '2019-11-25 06:18:51.885747'),
(12, 'auth', '0007_alter_validators_add_error_messages', '2019-11-25 06:18:51.905199'),
(13, 'auth', '0008_alter_user_username_max_length', '2019-11-25 06:18:51.971213'),
(14, 'auth', '0009_alter_user_last_name_max_length', '2019-11-25 06:18:52.034952'),
(15, 'auth', '0010_alter_group_name_max_length', '2019-11-25 06:18:52.092108'),
(16, 'auth', '0011_update_proxy_permissions', '2019-11-25 06:18:52.128795'),
(17, 'books', '0001_initial', '2019-11-25 06:18:52.144822'),
(18, 'borrows', '0001_initial', '2019-11-25 06:18:52.161170'),
(19, 'comments', '0001_initial', '2019-11-25 06:18:52.176499'),
(20, 'managers', '0001_initial', '2019-11-25 06:18:52.192304'),
(21, 'sessions', '0001_initial', '2019-11-25 06:18:52.245870'),
(22, 'students', '0001_initial', '2019-11-25 06:18:52.281182');

-- --------------------------------------------------------

--
-- 表的结构 `django_session`
--

CREATE TABLE IF NOT EXISTS `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `django_session`
--

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('097db3zzgh3f282csy4muymbvh2xgf0y', 'Y2U4Nzc3ZTljNTgzNWYwMDM4NmZhMTkwODgyMzcyZDQ5MjhjZWFlMzp7InVzZXJpbmZvIjp7Im5vIjoiMTIzNDU2Nzg5MCIsIm5hbWUiOiJcdTVmMjBcdTRlMDkiLCJjbGFzc19maWVsZCI6IjIiLCJtYWpvciI6Ilx1OGJhMVx1N2I5N1x1NjczYVx1NzlkMVx1NWI2Nlx1NGUwZVx1NjI4MFx1NjcyZiIsImNvbnRhY3QiOiIxNTIwMTY5MzEyMCJ9fQ==', '2019-12-09 17:49:19.848770'),
('12917mufkpyrc5wqnqe6irzts2l4rvwc', 'Y2U4Nzc3ZTljNTgzNWYwMDM4NmZhMTkwODgyMzcyZDQ5MjhjZWFlMzp7InVzZXJpbmZvIjp7Im5vIjoiMTIzNDU2Nzg5MCIsIm5hbWUiOiJcdTVmMjBcdTRlMDkiLCJjbGFzc19maWVsZCI6IjIiLCJtYWpvciI6Ilx1OGJhMVx1N2I5N1x1NjczYVx1NzlkMVx1NWI2Nlx1NGUwZVx1NjI4MFx1NjcyZiIsImNvbnRhY3QiOiIxNTIwMTY5MzEyMCJ9fQ==', '2019-12-09 07:10:13.348307'),
('1o99rx6k23cnajw0qq29qhsi1k9frgdo', 'OWNkMjliZTkwZjE1ZTY0ZTk5Y2I0MjA1NjUwZTA0MDg2ZTJlZjNiZDp7InVzZXJpbmZvIjp7ImlkIjoyNDMsInVzZXJuYW1lIjoiYXRLc09wdGlvbiIsInBhc3N3b3JkIjoicGJrZGYyX3NoYTI1NiQxNTAwMDAkQUlkZXVlamJhVThnJFBkcjRBdE4rOW4vS1IwdGdZMkNqTXVVWlJMQXJtaWxDaGNVd1k0V05hd1k9IiwibmFtZSI6Ilx1NTM0OFx1NWViN1x1NGZjYSIsInJvbGUiOjB9fQ==', '2019-12-03 05:51:04.646712'),
('2gytyy9vzdv7bu1q2rn049eah3beg5mj', 'ODNhMzhhZjJjNjEwMTM2ZjIxMDM4ZjY0MTZjODIzOTYzMDQzYjI3NDp7fQ==', '2019-12-03 04:03:02.257268'),
('2uvywduc95dbj7q0g9fhnn0r7t1a6j3y', 'Y2U4Nzc3ZTljNTgzNWYwMDM4NmZhMTkwODgyMzcyZDQ5MjhjZWFlMzp7InVzZXJpbmZvIjp7Im5vIjoiMTIzNDU2Nzg5MCIsIm5hbWUiOiJcdTVmMjBcdTRlMDkiLCJjbGFzc19maWVsZCI6IjIiLCJtYWpvciI6Ilx1OGJhMVx1N2I5N1x1NjczYVx1NzlkMVx1NWI2Nlx1NGUwZVx1NjI4MFx1NjcyZiIsImNvbnRhY3QiOiIxNTIwMTY5MzEyMCJ9fQ==', '2019-12-09 18:55:37.946423'),
('33wvv22xrbt7l7ox5saymwn3m6912f9g', 'Y2U4Nzc3ZTljNTgzNWYwMDM4NmZhMTkwODgyMzcyZDQ5MjhjZWFlMzp7InVzZXJpbmZvIjp7Im5vIjoiMTIzNDU2Nzg5MCIsIm5hbWUiOiJcdTVmMjBcdTRlMDkiLCJjbGFzc19maWVsZCI6IjIiLCJtYWpvciI6Ilx1OGJhMVx1N2I5N1x1NjczYVx1NzlkMVx1NWI2Nlx1NGUwZVx1NjI4MFx1NjcyZiIsImNvbnRhY3QiOiIxNTIwMTY5MzEyMCJ9fQ==', '2019-12-10 03:33:04.506615'),
('4cf14mh4y93zz5fh3fmmwn8487503t9f', 'Y2U4Nzc3ZTljNTgzNWYwMDM4NmZhMTkwODgyMzcyZDQ5MjhjZWFlMzp7InVzZXJpbmZvIjp7Im5vIjoiMTIzNDU2Nzg5MCIsIm5hbWUiOiJcdTVmMjBcdTRlMDkiLCJjbGFzc19maWVsZCI6IjIiLCJtYWpvciI6Ilx1OGJhMVx1N2I5N1x1NjczYVx1NzlkMVx1NWI2Nlx1NGUwZVx1NjI4MFx1NjcyZiIsImNvbnRhY3QiOiIxNTIwMTY5MzEyMCJ9fQ==', '2019-11-27 17:06:30.547577'),
('6fbnpais9woja69btsz2nd9mlf667smc', 'Y2U4Nzc3ZTljNTgzNWYwMDM4NmZhMTkwODgyMzcyZDQ5MjhjZWFlMzp7InVzZXJpbmZvIjp7Im5vIjoiMTIzNDU2Nzg5MCIsIm5hbWUiOiJcdTVmMjBcdTRlMDkiLCJjbGFzc19maWVsZCI6IjIiLCJtYWpvciI6Ilx1OGJhMVx1N2I5N1x1NjczYVx1NzlkMVx1NWI2Nlx1NGUwZVx1NjI4MFx1NjcyZiIsImNvbnRhY3QiOiIxNTIwMTY5MzEyMCJ9fQ==', '2019-11-27 06:20:35.366403'),
('6kddfy5k29qtxigvn812ievu664y8y2s', 'ODNhMzhhZjJjNjEwMTM2ZjIxMDM4ZjY0MTZjODIzOTYzMDQzYjI3NDp7fQ==', '2019-11-28 20:02:47.741688'),
('8lsfjhj9z1ihura9xb7sugwykwb1tgs1', 'ZDRjMGM3NWFkZTdkZWJhNDU1YTc0ZDE3MjM5ZjI1NThmOWRkNjBjYzp7InVzZXJpbmZvIjp7ImlkIjoyNDEsInVzZXJuYW1lIjoid2tqIiwicGFzc3dvcmQiOiJwYmtkZjJfc2hhMjU2JDEwMDAwMCQ4SzNMZFE3WU5jRTAkYXBFWUdFVVlXbGFBSVZISUhCRnJtbU9CZEFvSTN4UncxeUhqV29DMzRCST0iLCJuYW1lIjoid2tqIiwicm9sZSI6Mn19', '2019-12-13 16:28:49.855423'),
('a82xwjig4sm9ri0jouhsk2hx97ve32dg', 'Y2U4Nzc3ZTljNTgzNWYwMDM4NmZhMTkwODgyMzcyZDQ5MjhjZWFlMzp7InVzZXJpbmZvIjp7Im5vIjoiMTIzNDU2Nzg5MCIsIm5hbWUiOiJcdTVmMjBcdTRlMDkiLCJjbGFzc19maWVsZCI6IjIiLCJtYWpvciI6Ilx1OGJhMVx1N2I5N1x1NjczYVx1NzlkMVx1NWI2Nlx1NGUwZVx1NjI4MFx1NjcyZiIsImNvbnRhY3QiOiIxNTIwMTY5MzEyMCJ9fQ==', '2019-11-30 15:39:29.401297'),
('aa2ud0pgncnrixslp9oi84qn2pa3tl97', 'Y2U4Nzc3ZTljNTgzNWYwMDM4NmZhMTkwODgyMzcyZDQ5MjhjZWFlMzp7InVzZXJpbmZvIjp7Im5vIjoiMTIzNDU2Nzg5MCIsIm5hbWUiOiJcdTVmMjBcdTRlMDkiLCJjbGFzc19maWVsZCI6IjIiLCJtYWpvciI6Ilx1OGJhMVx1N2I5N1x1NjczYVx1NzlkMVx1NWI2Nlx1NGUwZVx1NjI4MFx1NjcyZiIsImNvbnRhY3QiOiIxNTIwMTY5MzEyMCJ9fQ==', '2019-12-09 08:14:59.854124'),
('ato4q4py2rz8beo409mbt2artniqp92c', 'Y2U4Nzc3ZTljNTgzNWYwMDM4NmZhMTkwODgyMzcyZDQ5MjhjZWFlMzp7InVzZXJpbmZvIjp7Im5vIjoiMTIzNDU2Nzg5MCIsIm5hbWUiOiJcdTVmMjBcdTRlMDkiLCJjbGFzc19maWVsZCI6IjIiLCJtYWpvciI6Ilx1OGJhMVx1N2I5N1x1NjczYVx1NzlkMVx1NWI2Nlx1NGUwZVx1NjI4MFx1NjcyZiIsImNvbnRhY3QiOiIxNTIwMTY5MzEyMCJ9fQ==', '2019-11-28 07:59:16.497628'),
('c2j3w81myrwfunxogwztxf3r9u99477i', 'Y2U4Nzc3ZTljNTgzNWYwMDM4NmZhMTkwODgyMzcyZDQ5MjhjZWFlMzp7InVzZXJpbmZvIjp7Im5vIjoiMTIzNDU2Nzg5MCIsIm5hbWUiOiJcdTVmMjBcdTRlMDkiLCJjbGFzc19maWVsZCI6IjIiLCJtYWpvciI6Ilx1OGJhMVx1N2I5N1x1NjczYVx1NzlkMVx1NWI2Nlx1NGUwZVx1NjI4MFx1NjcyZiIsImNvbnRhY3QiOiIxNTIwMTY5MzEyMCJ9fQ==', '2019-11-27 19:52:07.296933'),
('dw96okobq0cjpyxab417zdcsbkemvajm', 'Y2U4Nzc3ZTljNTgzNWYwMDM4NmZhMTkwODgyMzcyZDQ5MjhjZWFlMzp7InVzZXJpbmZvIjp7Im5vIjoiMTIzNDU2Nzg5MCIsIm5hbWUiOiJcdTVmMjBcdTRlMDkiLCJjbGFzc19maWVsZCI6IjIiLCJtYWpvciI6Ilx1OGJhMVx1N2I5N1x1NjczYVx1NzlkMVx1NWI2Nlx1NGUwZVx1NjI4MFx1NjcyZiIsImNvbnRhY3QiOiIxNTIwMTY5MzEyMCJ9fQ==', '2019-12-10 02:42:57.751331'),
('dyvzl479irryy9uv95xr1c5gdel79ziw', 'NDAxNzhjMTk4MzEwMDEwYTBmMmZmZDczMjY0MGM1NDE3NTNhMWI5ODp7InVzZXJpbmZvIjp7Im5vIjoiMTExMzAwMDAwMSIsIm5hbWUiOiJcdTk2NDhcdTVmYjdcdTU3NjQiLCJjbGFzc19maWVsZCI6ImNqMTFCMTBtcyIsIm1ham9yIjoiXHU3ZjhlXHU2NzJmXHU1YjY2IiwiY29udGFjdCI6IjEzMTQ2Mzg1OTk5In19', '2019-12-03 07:25:38.600341'),
('ie8o3u5lot3m5b7tm3bue0bpe2e3wvmp', 'MTRkZjk1YjZlNTc3YzlmZjVjMWFkZGIyNDg4N2I4YTdmM2U1YzVhMTp7InVzZXJpbmZvIjp7ImlkIjoyNDQsInVzZXJuYW1lIjoid3VrYW5nanVuIiwicGFzc3dvcmQiOiJwYmtkZjJfc2hhMjU2JDE1MDAwMCRBTDgyMHppUm9sZjEkeFI0WWdNKzNtSkQ1cXVzVmpVTkZZVHY0Q1F4ZDlMdjhrMUR0RnlzbTlxST0iLCJuYW1lIjoiXHU1MzQ4XHU1ZWI3XHU0ZmNhIiwicm9sZSI6MX19', '2019-11-30 13:47:22.006747'),
('iuukyhdxsm0bj72g5j0kuf50ufv9nvqg', 'ODNhMzhhZjJjNjEwMTM2ZjIxMDM4ZjY0MTZjODIzOTYzMDQzYjI3NDp7fQ==', '2019-12-03 07:35:15.483794'),
('ixed4ldoxhg4bl19t176g2ipkhkshmx4', 'Y2U4Nzc3ZTljNTgzNWYwMDM4NmZhMTkwODgyMzcyZDQ5MjhjZWFlMzp7InVzZXJpbmZvIjp7Im5vIjoiMTIzNDU2Nzg5MCIsIm5hbWUiOiJcdTVmMjBcdTRlMDkiLCJjbGFzc19maWVsZCI6IjIiLCJtYWpvciI6Ilx1OGJhMVx1N2I5N1x1NjczYVx1NzlkMVx1NWI2Nlx1NGUwZVx1NjI4MFx1NjcyZiIsImNvbnRhY3QiOiIxNTIwMTY5MzEyMCJ9fQ==', '2019-12-10 05:24:55.467322'),
('j1zcxrhq2e9vqz7f345li45bxn17zhfw', 'Y2U4Nzc3ZTljNTgzNWYwMDM4NmZhMTkwODgyMzcyZDQ5MjhjZWFlMzp7InVzZXJpbmZvIjp7Im5vIjoiMTIzNDU2Nzg5MCIsIm5hbWUiOiJcdTVmMjBcdTRlMDkiLCJjbGFzc19maWVsZCI6IjIiLCJtYWpvciI6Ilx1OGJhMVx1N2I5N1x1NjczYVx1NzlkMVx1NWI2Nlx1NGUwZVx1NjI4MFx1NjcyZiIsImNvbnRhY3QiOiIxNTIwMTY5MzEyMCJ9fQ==', '2019-11-27 03:19:13.331903'),
('j89fe4zplgevkteoewfy8tyj79pfgh97', 'MGEyNjZhN2ExM2JmYzJjOTQxMjZmMzczZWFhZjMwNDI3NjI5YThkYjp7InVzZXJpbmZvIjp7Im5vIjoiMTIzNDU2Nzg5MCIsIm5hbWUiOiJ3dWtuYWdqdW4iLCJjbGFzc19maWVsZCI6IkMwMSIsIm1ham9yIjoicnVhbmppYW5nb25nY2hlbmciLCJjb250YWN0IjoiMTMxMjM0NTQ1NjcifX0=', '2019-12-03 13:53:46.230082'),
('jbhztkilwp7mkn7luj64ab1gc65vpq3k', 'Y2U4Nzc3ZTljNTgzNWYwMDM4NmZhMTkwODgyMzcyZDQ5MjhjZWFlMzp7InVzZXJpbmZvIjp7Im5vIjoiMTIzNDU2Nzg5MCIsIm5hbWUiOiJcdTVmMjBcdTRlMDkiLCJjbGFzc19maWVsZCI6IjIiLCJtYWpvciI6Ilx1OGJhMVx1N2I5N1x1NjczYVx1NzlkMVx1NWI2Nlx1NGUwZVx1NjI4MFx1NjcyZiIsImNvbnRhY3QiOiIxNTIwMTY5MzEyMCJ9fQ==', '2019-12-09 17:05:39.871331'),
('ji27w5mvrafque03tkn6ssw898dnbjt8', 'MGEyNjZhN2ExM2JmYzJjOTQxMjZmMzczZWFhZjMwNDI3NjI5YThkYjp7InVzZXJpbmZvIjp7Im5vIjoiMTIzNDU2Nzg5MCIsIm5hbWUiOiJ3dWtuYWdqdW4iLCJjbGFzc19maWVsZCI6IkMwMSIsIm1ham9yIjoicnVhbmppYW5nb25nY2hlbmciLCJjb250YWN0IjoiMTMxMjM0NTQ1NjcifX0=', '2019-12-09 05:14:02.677106'),
('lacx3g3ebsm0xjxxk6afu5iedydv5y93', 'Y2U4Nzc3ZTljNTgzNWYwMDM4NmZhMTkwODgyMzcyZDQ5MjhjZWFlMzp7InVzZXJpbmZvIjp7Im5vIjoiMTIzNDU2Nzg5MCIsIm5hbWUiOiJcdTVmMjBcdTRlMDkiLCJjbGFzc19maWVsZCI6IjIiLCJtYWpvciI6Ilx1OGJhMVx1N2I5N1x1NjczYVx1NzlkMVx1NWI2Nlx1NGUwZVx1NjI4MFx1NjcyZiIsImNvbnRhY3QiOiIxNTIwMTY5MzEyMCJ9fQ==', '2019-11-27 08:47:07.966405'),
('m3r976mi9ow0vhnjeruo47we9auk5mau', 'YTdkNzcxNzI5YjE4NDU0ZGEyYjUzNTcxZmZjNzkwM2VhMmI5ZWI5Nzp7InVzZXJpbmZvIjp7Im5vIjoiMTExMzAwMDAwNCIsIm5hbWUiOiJcdTVkMTRcdTViNTBcdTUwNjUiLCJjbGFzc19maWVsZCI6ImNqMTFCMTBtcyIsIm1ham9yIjoiXHU3ZjhlXHU2NzJmXHU1YjY2IiwiY29udGFjdCI6IjEzNTk3Nzg1MTQ1In19', '2019-12-03 07:26:42.045746'),
('mv8pdgbb1osknj1qg7v7d7kj3fokr5v4', 'Y2U4Nzc3ZTljNTgzNWYwMDM4NmZhMTkwODgyMzcyZDQ5MjhjZWFlMzp7InVzZXJpbmZvIjp7Im5vIjoiMTIzNDU2Nzg5MCIsIm5hbWUiOiJcdTVmMjBcdTRlMDkiLCJjbGFzc19maWVsZCI6IjIiLCJtYWpvciI6Ilx1OGJhMVx1N2I5N1x1NjczYVx1NzlkMVx1NWI2Nlx1NGUwZVx1NjI4MFx1NjcyZiIsImNvbnRhY3QiOiIxNTIwMTY5MzEyMCJ9fQ==', '2019-11-28 11:41:36.955520'),
('np2xo91bgyw0vy50uvguhozz7px7c8nk', 'ZmZkMzFmYWVkMjEwMDkwNDk1NTg5N2EzY2IwYzA2NTgwOGVjMzgzNDp7InVzZXJpbmZvIjp7Im5vIjoiMTExMzAwMDAwMiIsIm5hbWUiOiJcdTk2NDhcdTY4YTdcdTViYmUiLCJjbGFzc19maWVsZCI6ImNqMTFCMTBtcyIsIm1ham9yIjoiXHU3ZjhlXHU2NzJmXHU1YjY2IiwiY29udGFjdCI6IjEzMzgxMTE4NzQ4In19', '2019-12-03 07:29:49.067549'),
('pg3r6b62ktai3ijigzhh3l1w0u9orqcd', 'NDAxNzhjMTk4MzEwMDEwYTBmMmZmZDczMjY0MGM1NDE3NTNhMWI5ODp7InVzZXJpbmZvIjp7Im5vIjoiMTExMzAwMDAwMSIsIm5hbWUiOiJcdTk2NDhcdTVmYjdcdTU3NjQiLCJjbGFzc19maWVsZCI6ImNqMTFCMTBtcyIsIm1ham9yIjoiXHU3ZjhlXHU2NzJmXHU1YjY2IiwiY29udGFjdCI6IjEzMTQ2Mzg1OTk5In19', '2019-11-30 16:29:43.692018'),
('r7pmxn6vp4jc3ouedkg3rjapxbadd6wv', 'Y2U4Nzc3ZTljNTgzNWYwMDM4NmZhMTkwODgyMzcyZDQ5MjhjZWFlMzp7InVzZXJpbmZvIjp7Im5vIjoiMTIzNDU2Nzg5MCIsIm5hbWUiOiJcdTVmMjBcdTRlMDkiLCJjbGFzc19maWVsZCI6IjIiLCJtYWpvciI6Ilx1OGJhMVx1N2I5N1x1NjczYVx1NzlkMVx1NWI2Nlx1NGUwZVx1NjI4MFx1NjcyZiIsImNvbnRhY3QiOiIxNTIwMTY5MzEyMCJ9fQ==', '2019-11-29 03:15:17.980307'),
('shaaw7ji4u4gwn1yfhvndx8yc2xjfsep', 'NDAxNzhjMTk4MzEwMDEwYTBmMmZmZDczMjY0MGM1NDE3NTNhMWI5ODp7InVzZXJpbmZvIjp7Im5vIjoiMTExMzAwMDAwMSIsIm5hbWUiOiJcdTk2NDhcdTVmYjdcdTU3NjQiLCJjbGFzc19maWVsZCI6ImNqMTFCMTBtcyIsIm1ham9yIjoiXHU3ZjhlXHU2NzJmXHU1YjY2IiwiY29udGFjdCI6IjEzMTQ2Mzg1OTk5In19', '2019-12-03 04:33:48.610038'),
('tua69f82ha6ptfhrk9sg1fdnvdwx97mv', 'Y2U4Nzc3ZTljNTgzNWYwMDM4NmZhMTkwODgyMzcyZDQ5MjhjZWFlMzp7InVzZXJpbmZvIjp7Im5vIjoiMTIzNDU2Nzg5MCIsIm5hbWUiOiJcdTVmMjBcdTRlMDkiLCJjbGFzc19maWVsZCI6IjIiLCJtYWpvciI6Ilx1OGJhMVx1N2I5N1x1NjczYVx1NzlkMVx1NWI2Nlx1NGUwZVx1NjI4MFx1NjcyZiIsImNvbnRhY3QiOiIxNTIwMTY5MzEyMCJ9fQ==', '2019-11-28 07:12:59.663711'),
('tz7t6bkm9skpttchbc7es3basul8fjxg', 'Y2U4Nzc3ZTljNTgzNWYwMDM4NmZhMTkwODgyMzcyZDQ5MjhjZWFlMzp7InVzZXJpbmZvIjp7Im5vIjoiMTIzNDU2Nzg5MCIsIm5hbWUiOiJcdTVmMjBcdTRlMDkiLCJjbGFzc19maWVsZCI6IjIiLCJtYWpvciI6Ilx1OGJhMVx1N2I5N1x1NjczYVx1NzlkMVx1NWI2Nlx1NGUwZVx1NjI4MFx1NjcyZiIsImNvbnRhY3QiOiIxNTIwMTY5MzEyMCJ9fQ==', '2019-12-09 06:40:18.447624'),
('urr9658qsbdv1wg5nkb6elownvn0s7g3', 'Y2U4Nzc3ZTljNTgzNWYwMDM4NmZhMTkwODgyMzcyZDQ5MjhjZWFlMzp7InVzZXJpbmZvIjp7Im5vIjoiMTIzNDU2Nzg5MCIsIm5hbWUiOiJcdTVmMjBcdTRlMDkiLCJjbGFzc19maWVsZCI6IjIiLCJtYWpvciI6Ilx1OGJhMVx1N2I5N1x1NjczYVx1NzlkMVx1NWI2Nlx1NGUwZVx1NjI4MFx1NjcyZiIsImNvbnRhY3QiOiIxNTIwMTY5MzEyMCJ9fQ==', '2019-11-28 16:18:21.052625'),
('usijwcoh5jcjhdt23996q5lkinebt8mb', 'Y2U4Nzc3ZTljNTgzNWYwMDM4NmZhMTkwODgyMzcyZDQ5MjhjZWFlMzp7InVzZXJpbmZvIjp7Im5vIjoiMTIzNDU2Nzg5MCIsIm5hbWUiOiJcdTVmMjBcdTRlMDkiLCJjbGFzc19maWVsZCI6IjIiLCJtYWpvciI6Ilx1OGJhMVx1N2I5N1x1NjczYVx1NzlkMVx1NWI2Nlx1NGUwZVx1NjI4MFx1NjcyZiIsImNvbnRhY3QiOiIxNTIwMTY5MzEyMCJ9fQ==', '2019-12-09 07:14:24.786334'),
('v8ym93yg5cq43hx5phormz05dy7m8pn9', 'Y2U4Nzc3ZTljNTgzNWYwMDM4NmZhMTkwODgyMzcyZDQ5MjhjZWFlMzp7InVzZXJpbmZvIjp7Im5vIjoiMTIzNDU2Nzg5MCIsIm5hbWUiOiJcdTVmMjBcdTRlMDkiLCJjbGFzc19maWVsZCI6IjIiLCJtYWpvciI6Ilx1OGJhMVx1N2I5N1x1NjczYVx1NzlkMVx1NWI2Nlx1NGUwZVx1NjI4MFx1NjcyZiIsImNvbnRhY3QiOiIxNTIwMTY5MzEyMCJ9fQ==', '2019-11-28 12:37:27.615010'),
('wakuejf66sst05v9h8ytbvltb1g4lqag', 'Y2U4Nzc3ZTljNTgzNWYwMDM4NmZhMTkwODgyMzcyZDQ5MjhjZWFlMzp7InVzZXJpbmZvIjp7Im5vIjoiMTIzNDU2Nzg5MCIsIm5hbWUiOiJcdTVmMjBcdTRlMDkiLCJjbGFzc19maWVsZCI6IjIiLCJtYWpvciI6Ilx1OGJhMVx1N2I5N1x1NjczYVx1NzlkMVx1NWI2Nlx1NGUwZVx1NjI4MFx1NjcyZiIsImNvbnRhY3QiOiIxNTIwMTY5MzEyMCJ9fQ==', '2019-11-27 05:41:26.664250'),
('y5j761nk4qqhzu6tgwydhc3hk6dafm44', 'Y2U4Nzc3ZTljNTgzNWYwMDM4NmZhMTkwODgyMzcyZDQ5MjhjZWFlMzp7InVzZXJpbmZvIjp7Im5vIjoiMTIzNDU2Nzg5MCIsIm5hbWUiOiJcdTVmMjBcdTRlMDkiLCJjbGFzc19maWVsZCI6IjIiLCJtYWpvciI6Ilx1OGJhMVx1N2I5N1x1NjczYVx1NzlkMVx1NWI2Nlx1NGUwZVx1NjI4MFx1NjcyZiIsImNvbnRhY3QiOiIxNTIwMTY5MzEyMCJ9fQ==', '2019-11-27 20:08:24.507936'),
('y7axhtd2nm6p7weoprxcdtvu3gj7nv7v', 'Y2U4Nzc3ZTljNTgzNWYwMDM4NmZhMTkwODgyMzcyZDQ5MjhjZWFlMzp7InVzZXJpbmZvIjp7Im5vIjoiMTIzNDU2Nzg5MCIsIm5hbWUiOiJcdTVmMjBcdTRlMDkiLCJjbGFzc19maWVsZCI6IjIiLCJtYWpvciI6Ilx1OGJhMVx1N2I5N1x1NjczYVx1NzlkMVx1NWI2Nlx1NGUwZVx1NjI4MFx1NjcyZiIsImNvbnRhY3QiOiIxNTIwMTY5MzEyMCJ9fQ==', '2019-12-10 03:27:11.131381'),
('yemzaxsmzgv60oa0oiy0ww2cay0kno54', 'Y2U4Nzc3ZTljNTgzNWYwMDM4NmZhMTkwODgyMzcyZDQ5MjhjZWFlMzp7InVzZXJpbmZvIjp7Im5vIjoiMTIzNDU2Nzg5MCIsIm5hbWUiOiJcdTVmMjBcdTRlMDkiLCJjbGFzc19maWVsZCI6IjIiLCJtYWpvciI6Ilx1OGJhMVx1N2I5N1x1NjczYVx1NzlkMVx1NWI2Nlx1NGUwZVx1NjI4MFx1NjcyZiIsImNvbnRhY3QiOiIxNTIwMTY5MzEyMCJ9fQ==', '2019-11-27 09:32:49.771780');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auth_group`
--
ALTER TABLE `auth_group`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  ADD KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`);

--
-- Indexes for table `auth_user`
--
ALTER TABLE `auth_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  ADD KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`);

--
-- Indexes for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  ADD KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `bm_book`
--
ALTER TABLE `bm_book`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `bm_borrow`
--
ALTER TABLE `bm_borrow`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bm_comment`
--
ALTER TABLE `bm_comment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bm_manager`
--
ALTER TABLE `bm_manager`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bm_reservation`
--
ALTER TABLE `bm_reservation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bm_student`
--
ALTER TABLE `bm_student`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  ADD KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`);

--
-- Indexes for table `django_content_type`
--
ALTER TABLE `django_content_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`);

--
-- Indexes for table `django_migrations`
--
ALTER TABLE `django_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `django_session`
--
ALTER TABLE `django_session`
  ADD PRIMARY KEY (`session_key`),
  ADD KEY `django_session_expire_date_a5c62663` (`expire_date`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auth_group`
--
ALTER TABLE `auth_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `auth_permission`
--
ALTER TABLE `auth_permission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=49;
--
-- AUTO_INCREMENT for table `auth_user`
--
ALTER TABLE `auth_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `bm_borrow`
--
ALTER TABLE `bm_borrow`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `bm_comment`
--
ALTER TABLE `bm_comment`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `bm_manager`
--
ALTER TABLE `bm_manager`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'id',AUTO_INCREMENT=254;
--
-- AUTO_INCREMENT for table `bm_reservation`
--
ALTER TABLE `bm_reservation`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `django_content_type`
--
ALTER TABLE `django_content_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `django_migrations`
--
ALTER TABLE `django_migrations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
--
-- 限制导出的表
--

--
-- 限制表 `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`);

--
-- 限制表 `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

--
-- 限制表 `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- 限制表 `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- 限制表 `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  ADD CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
