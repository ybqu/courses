#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@File    :   data.py
@Time    :   2019/11/25 02:42:24
@Author  :   Quxiansen
@Version :   1.0
@Contact :   raogx.vip@hotmail.com
@License :   (C)Copyright 2017-2018, Liugroup-NLPR-CASIA
@Desc    :   定义返回数据格式化工具类
'''

# here put the import lib


class Formatter(object):
    @staticmethod
    def return_data(code=0, msg='', data=[]):
        """ 格式化返回数据 
        :param code: 返回状态码
        :param msg: 返回信息
        :param data: 返回数据
        """
        return {"code": code, "msg": msg, "data": data}

    @staticmethod
    def return_table_data(code, msg, count, data):
        """ 格式化表格渲染数据
        :param code: 返回状态码
        :param msg: 返回信息
        :param count: 返回信息总数
        :param data: 返回数据
        """
        return {"code": code, "msg": msg, "count": count, "data": data}

    @staticmethod
    def return_msg(code, msg):
        """ 格式化返回数据
        :param code: 返回状态码
        :param msg: 返回信息

        """
        return {"code": code, "msg": msg}
