#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@File    :   views.py
@Time    :   2019/11/24 01:55:40
@Author  :   Quxiansen
@Version :   1.0
@Contact :   raogx.vip@hotmail.com
@License :   (C)Copyright 2017-2018, Liugroup-NLPR-CASIA
@Desc    :   None
'''

# here put the import lib
import json
from django.shortcuts import render, HttpResponse
from .models import BmStudent
from ..books.models import BmBook
from ..borrows.models import BmReservation
from django.contrib.auth.hashers import make_password, check_password
from utils.data import Formatter
# Create your views here.


def login(request):
    """ 渲染学生登录界面 """
    if request.method == 'GET':
        return render(request, 'student/login.html')
    elif request.method == 'POST':
        no = request.POST.get('no', None)
        password = request.POST.get('password', None)

        try:
            stu_object = BmStudent.objects.get(no=no)  # 查询学生信息
            code = 1 if check_password(
                password, stu_object.password) else 0  # check 密码
        except BmStudent.DoesNotExist:
            code = 0
        finally:
            if code == 1:  # 登录成功,设置session保存登录状态
                request.session['userinfo'] = stu_object.to_json()
            return HttpResponse(json.dumps(Formatter.return_data(code)), content_type="application/json")


def new_pwd(request):
    """ 渲染学生修改密码界面 """
    if request.method == 'GET':
        return render(request, 'student/new_pwd.html')
    elif request.method == 'POST':
        no = request.POST.get('no', None)
        old_password = request.POST.get('old_password', None)
        new_password = request.POST.get('new_password', None)

        try:
            stu_object = BmStudent.objects.get(no=no)
            if check_password(old_password, stu_object.password):  # 修改密码
                stu_object.password = make_password(new_password)
                stu_object.save()
                code = 1
            else:
                code = 0
        except BmStudent.DoesNotExist:
            code = 0
        finally:
            return HttpResponse(json.dumps(Formatter.return_data(code)), content_type='application/json')


def index(request):
    """ 渲染学生主页面 """
    if request.method == "GET":
        return render(request, 'student/index.html', {'cur_user': request.session.get('userinfo')['no']})

def reserve_info(request):
    """ 渲染预约信息界面 """
    if request.method == 'POST':
        reserve_objects = BmReservation.objects.filter(stu_no=request.session.get('userinfo')['no'])

        reservations = []
        for reservation in reserve_objects:
            reservation = reservation.to_json()
            try:
                book = BmBook.objects.get(no=reservation['book_no'])
                reservation['book_title'] = book.title
                reservation['is_borrowed'] = 1 if book.inventory > book.lend_num else 0
            except BmBook.DoesNotExist:
                # reservation['book_title'] = ''
                pass
            finally:
                reservations.append(reservation)
        return HttpResponse(json.dumps(Formatter.return_table_data(0, '', len(reservations), reservations)))
        