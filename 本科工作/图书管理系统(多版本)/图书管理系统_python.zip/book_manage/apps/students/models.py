#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@File    :   models.py
@Time    :   2019/11/23 16:59:36
@Author  :   Qu Yuanbin 
@Version :   1.0
@Contact :   2191002033@cnu.edu.cn
@License :   
@Desc    :   学生 APP
'''

# here put the import lib

from django.db import models

# Create your models here.


class BmStudent(models.Model):
    """ 学生信息类 """
    no = models.CharField(primary_key=True, max_length=10)
    password = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    # Field renamed because it was a Python reserved word.
    class_field = models.CharField(db_column='class', max_length=255)
    major = models.CharField(max_length=255)
    contact = models.CharField(max_length=11)

    class Meta:
        managed = False
        db_table = 'bm_student'

    def to_json(self):
        """ 将类对象转换为 json 格式 """
        return {"no": self.no, "name": self.name,
                "class_field": self.class_field, "major": self.major, "contact": self.contact}
    def to_string(self):
        passwd = "******"
        return {"no": self.no, "password": passwd, "name": self.name, "class": self.class_field, "major": self.major, "contact": self.contact}
