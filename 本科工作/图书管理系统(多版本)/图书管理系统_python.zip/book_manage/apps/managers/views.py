import json
import xlrd
from django.contrib.auth.hashers import make_password, check_password
from django.shortcuts import render, HttpResponse,redirect
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile
from .models import BmManager
from utils.data import Formatter
from ..students.models import BmStudent
from ..books.models import BmBook
from urllib.parse import unquote
from django.core.files.uploadedfile import InMemoryUploadedFile
# Create your views here.
def login(request):
    """ 渲染管理员登录界面 """
    if request.method == 'GET':
        return render(request, 'manager/login.html')

    elif request.method == 'POST':
        username = request.POST.get('username', None)
        password = request.POST.get('password', None)
        role = request.POST.get('role', None)
        man_option = 3
        try:
            man_object = BmManager.objects.get(username = username)  # 查询管理员信息

            code = 1 if check_password(
                password, man_object.password) else 0  # check 密码
            if man_object.role == 0:
                man_option = 0
            elif man_object.role == 1:
                man_option = 1
            elif man_object.role == 2:
                man_option = 2
        except BmManager.DoesNotExist:
            code = 0
        finally:
            if code == 1:  # 登录成功,设置session保存登录状态
                request.session['userinfo'] = man_object.to_json()
            result = {"code": code, "man_option": man_option}
            return HttpResponse(json.dumps(result, ensure_ascii=False), content_type="application/json,charset=utf-8")
            # return HttpResponse(json.dumps(Formatter.return_data(0,"",result), ensure_ascii=False), content_type="application/json,,charset=utf-8")

def pwd(request):
    """ 渲染管理员修改密码界面 """
    if request.method == 'GET':
        return render(request, 'manager/pwd.html')
    elif request.method == 'POST':
        username = request.POST.get("username")
        old_password = request.POST.get('old_password', None)
        new_password = request.POST.get('new_password', None)

        try:
            man_object = BmManager.objects.get(username=username)

            if check_password(old_password, man_object.password):  # 修改密码
                man_object.password = make_password(new_password)
                man_object.save()
                code = 1
            else:
                code = 0
        except BmManager.DoesNotExist:
            code = 0
        finally:
            result = {"code": code}
            return HttpResponse(json.dumps(result, ensure_ascii=False), content_type='application/json')
            # return HttpResponse(json.dumps(Formatter.return_data(0,"",result)), content_type='application/json')

def system_manager(request):
    """ 渲染系统管理员界面 """
    if request.method == 'GET':
        return render(request, 'manager/system_manager.html')
    elif request.method == 'POST':
        page = int(request.POST.get("page"))
        limit = int(request.POST.get("limit"))

        man_all = BmManager.objects.all()
        down = (page * limit) if (page * limit) < len(man_all) else len(man_all)
        man_all_slide = man_all[(page-1)*limit: down]
        data = []
        for manager in man_all_slide:
            data.append(manager.to_string())

        return HttpResponse(json.dumps(Formatter.return_table_data(0, '', len(man_all), data)), content_type='application/json')
        # return HttpResponse(json.dumps(data, ensure_ascii=False), content_type='application/json')


def add_manager(request):
    """渲染管理员添加页面"""
    if request.method == 'POST':
        man_username = request.POST.get("username")
        man_name = request.POST.get("name")
        man_password = make_password(request.POST.get("password"))
        man_role = request.POST.get("role")
        if BmManager.objects.filter(username=man_username):
            return HttpResponse(json.dumps(Formatter.return_msg(0, "username already exists")))
        else:
            BmManager.objects.create(username=man_username, name=man_name, password=man_password, role=man_role)
            # return render(request, 'manager/system_manager.html')
            return HttpResponse(json.dumps(Formatter.return_msg(1, "successful added")))

def edit_manager(request):
    """渲染管理员修改页面"""
    if request.method == 'POST':
        man_id = request.POST.get("id")
        man_username = request.POST.get("username")
        man_name = request.POST.get("name")
        man_password = make_password(request.POST.get("password"))
        role = request.POST.get("role")
        if role == "系统管理员":
            man_role = 0
        elif role == "学生管理员":
            man_role = 1
        else:
            man_role = 2

            # return HttpResponse(json.dumps(Formatter.return_msg(0, "username already exists")))

        if man_password == "******":
            BmManager.objects.filter(id=man_id).update(username=man_username, name=man_name, role=man_role)
        else:
            BmManager.objects.filter(id=man_id).update(username=man_username, name=man_name, password=man_password, role=man_role)
        return HttpResponse(json.dumps({"code":1}, ensure_ascii=False), content_type='application/json')
        # return HttpResponse(json.dumps(Formatter.return_msg(1, "successful updated")))




def del_manager(request):
    """渲染管理员删除页面"""
    if request.method == 'GET':
        man_id = request.GET["id"]
        BmManager.objects.filter(id=man_id).delete()
        return redirect("/manager/system_manager/")
        # return render(request, 'manager/system_manager.html')


def del_group_manager(request):
    if request.method == 'POST':
        ids = request.POST.getlist("ids")

        for id in ids:
            BmManager.objects.filter(id=id).delete()

        return HttpResponse(json.dumps({"code":1}, ensure_ascii=False), content_type='application/json')

def upload_group_manager(request):
    loadfile = request.FILES["file"]
    try:
        f = "temporary/manage.xlsx"
        default_storage.save(f, ContentFile(loadfile.read()))
        table = xlrd.open_workbook(f).sheet_by_index(0)

        for rowNum in range(table.nrows):
            if rowNum > 0:
                rowValue = table.row_values(rowNum)
                print(rowValue)
                BmManager(username=rowValue[0], name=rowValue[1], password=make_password(rowValue[2]), role=rowValue[3]).save()
    finally:
        default_storage.delete(f)

    return HttpResponse(json.dumps({"code":1}, ensure_ascii=False), content_type='application/json')



def student_manager(request):
    """ 渲染学生管理员界面 """
    if request.method == 'GET':
        return render(request, 'manager/student_manager.html')
    elif request.method == 'POST':
        page = int(request.POST.get("page"))
        limit = int(request.POST.get("limit"))


        stu_all = BmStudent.objects.all()
        down = (page * limit) if (page * limit) < len(stu_all) else len(stu_all)
        stu_all_slide = stu_all[(page - 1) * limit: down]
        data = []
        for student in stu_all_slide:
            data.append(student.to_string())

        return HttpResponse(json.dumps(Formatter.return_table_data(0, '', len(stu_all), data)),
                            content_type='application/json')

def add_student(request):
    """渲染学生添加页面"""
    if request.method == 'POST':
        stu_no = request.POST.get("no")
        stu_password = make_password(request.POST.get("password"))
        stu_name = request.POST.get("name")
        stu_class = request.POST.get("class")
        stu_major = request.POST.get("major")
        stu_contact = request.POST.get("contact")
        if BmStudent.objects.filter(no=stu_no):
            return HttpResponse(json.dumps(Formatter.return_msg(0, "username already exists")))
        else:
            BmStudent.objects.create(no=stu_no, password=stu_password, name=stu_name, class_field=stu_class, major=stu_major, contact=stu_contact)
            # return render(request, 'manager/system_manager.html')
            return HttpResponse(json.dumps(Formatter.return_msg(1, "successful added")))

def edit_student(request):
    """渲染学生修改页面"""
    if request.method == 'POST':
        stu_no = request.POST.get("no")
        stu_password = make_password(request.POST.get("password"))
        stu_name = request.POST.get("name")
        stu_class = request.POST.get("class_field")
        stu_major = request.POST.get("major")
        stu_contact = request.POST.get("contact")

            # return HttpResponse(json.dumps(Formatter.return_msg(0, "username already exists")))

        if stu_password == "******":
            BmStudent.objects.filter(no=stu_no).update(no=stu_no, name=stu_name, class_field=stu_class, major=stu_major, contact= stu_contact)
        else:
            BmStudent.objects.filter(no=stu_no).update(no=stu_no, password=stu_password, name=stu_name, class_field=stu_class, major=stu_major, contact= stu_contact)
        return HttpResponse(json.dumps({"code":1}, ensure_ascii=False), content_type='application/json')
        # return HttpResponse(json.dumps(Formatter.return_msg(1, "successful updated")))


def del_student(request):
    """渲染学生删除页面"""
    if request.method == 'GET':
        stu_no = request.GET["no"]
        BmStudent.objects.filter(no=stu_no).delete()
        return redirect("/manager/student_manager/")
        # return render(request, 'manager/system_manager.html')

def del_group_student(request):
    if request.method == 'POST':
        nos = request.POST.getlist("nos")

        for no in nos:
            BmStudent.objects.filter(no=no).delete()

        return HttpResponse(json.dumps({"code":1}, ensure_ascii=False), content_type='application/json')

def upload_group_student(request):
    loadfile = request.FILES["file"]
    try:
        f = "temporary/student.xlsx"
        default_storage.save(f, ContentFile(loadfile.read()))
        table = xlrd.open_workbook(f).sheet_by_index(0)

        for rowNum in range(table.nrows):
            if rowNum > 0:
                rowValue = table.row_values(rowNum)
                print(rowValue)
                BmStudent(no=rowValue[0], password=make_password(rowValue[1]), name=rowValue[2], class_field=rowValue[3], major=rowValue[4], contact=rowValue[5]).save()
    finally:
        default_storage.delete(f)

    return HttpResponse(json.dumps({"code":1}, ensure_ascii=False), content_type='application/json')

def book_manager(request):
    """ 渲染图书管理员界面 """
    if request.method == 'GET':
        return render(request, 'manager/book_manager.html')
    elif request.method == 'POST':
        page = int(request.POST.get("page"))
        limit = int(request.POST.get("limit"))

        book_all = BmBook.objects.all()
        down = (page * limit) if (page * limit) < len(book_all) else len(book_all)
        book_all_slide = book_all[(page - 1) * limit: down]
        data = []
        for book in book_all_slide:
            data.append(book.to_json())

        return HttpResponse(json.dumps(Formatter.return_table_data(0, '', len(book_all), data)),
                            content_type='application/json')

def del_book(request):
    """渲染图书删除页面"""
    if request.method == 'GET':
        book_no = request.GET["no"]
        BmBook.objects.filter(no=book_no).delete()
        return redirect("/manager/book_manager/")

def edit_book(request):
    """渲染图书修改页面"""
    if request.method == 'POST':
        book_no = request.POST.get("no")
        book_title = request.POST.get("title")
        book_author = request.POST.get("author")
        book_publisher = request.POST.get("publisher")
        book_p_date = request.POST.get("p_date")
        book_inventory = request.POST.get("inventory")
        book_lend_num = request.POST.get("lend_num")
        book_borrow_num = request.POST.get("borrow_num")


        BmBook.objects.filter(no=book_no).update(no=book_no, title=book_title, author=book_author,
                                                 publisher=book_publisher, p_date=book_p_date, inventory=book_inventory,lend_num=book_lend_num,borrow_num=book_borrow_num )
        return HttpResponse(json.dumps({"code": 1}, ensure_ascii=False), content_type='application/json')
        # return HttpResponse(json.dumps(Formatter.return_msg(1, "successful updated")))

def del_group_book(request):
    if request.method == 'POST':
        nos = request.POST.getlist("nos")

        for no in nos:
            BmBook.objects.filter(no=no).delete()

        return HttpResponse(json.dumps({"code":1}, ensure_ascii=False), content_type='application/json')

def upload_group_book(request):
    loadfile = request.FILES["file"]
    try:
        f = "temporary/book.xlsx"
        default_storage.save(f, ContentFile(loadfile.read()))
        table = xlrd.open_workbook(f).sheet_by_index(0)

        for rowNum in range(table.nrows):
            if rowNum > 0:
                rowValue = table.row_values(rowNum)
                print(rowValue)
                BmBook(no=rowValue[0], title=rowValue[1], author=rowValue[2], publisher=rowValue[3], p_date=rowValue[4], inventory=rowValue[5], lend_num=rowValue[6], borrow_num=rowValue[7]).save()
    finally:
        default_storage.delete(f)

    return HttpResponse(json.dumps({"code":1}, ensure_ascii=False), content_type='application/json')


def search_book(request):
    """ 渲染查询页面 """
    if request.method == "GET":
        return render(request, 'manager/book_search.html')

def booklist(request):
    if request.method == 'GET':
        info = request.GET.get('info')
        return render(request, 'manager/booklist.html',{'search_info': info})
    if request.method == 'POST':

        option = int(request.POST.get('option', None))
        info = request.POST.get('info', None)
        page = int(request.POST.get('page', None))
        limit = int(request.POST.get('limit', None))
        info = unquote(info)

        if option == 0:  # 书名查询
            length = len(BmBook.objects.filter(title__contains=info))
            book_objects = BmBook.objects.filter(title__contains=info)[(limit * (page - 1)): (limit * page )]
        elif option == 1:  # 作者查询
            length = len(BmBook.objects.filter(author__contains=info))
            book_objects = BmBook.objects.filter(author__contains=info)[(limit * (page - 1)): (limit * page )]
        elif option == 2:  # 出版社查询
            length = len(BmBook.objects.filter(publisher__contains=info))
            book_objects = BmBook.objects.filter(publisher__contains=info)[(limit * (page - 1)): (limit * page )]

        data = []
        for book in book_objects:
            data.append(book.to_json())
        return HttpResponse(json.dumps(Formatter.return_table_data(0, '', length, data)),
                            content_type="application/json")

def search_student(request):
    """ 渲染查询页面 """
    if request.method == "GET":
        return render(request, 'manager/student_search.html')

def studentlist(request):
    if request.method == 'GET':
        info = request.GET.get('info')
        return render(request, 'manager/studentlist.html',{'search_info': info})
    if request.method == 'POST':

        option = int(request.POST.get('option', None))
        info = request.POST.get('info', None)
        page = int(request.POST.get('page', None))
        limit = int(request.POST.get('limit', None))
        info = unquote(info)

        if option == 0:  # 学号查询
            length =len(BmStudent.objects.filter(no__contains=info))
            student_objects = BmStudent.objects.filter(no__contains=info)[(limit * (page - 1)): (limit * page )]
        elif option == 1:  # 姓名查询
            length = len(BmStudent.objects.filter(name__contains=info))
            student_objects = BmStudent.objects.filter(name__contains=info)[(limit * (page - 1)): (limit * page )]
        elif option == 2:  # 班级查询
            length = len(BmStudent.objects.filter(class_field__contains=info))
            student_objects = BmStudent.objects.filter(class_field__contains=info)[(limit * (page - 1)): (limit * page )]
        elif option == 3:  # 专业查询
            length = len(BmStudent.objects.filter(major__contains=info))
            student_objects = BmStudent.objects.filter(major__contains=info)[(limit * (page - 1)): (limit * page )]
        elif option == 4:  # 联系方式
            length = len(BmStudent.objects.filter(contact__contains=info))
            student_objects = BmStudent.objects.filter(contact__contains=info)[(limit * (page - 1)): (limit * page )]


        data = []
        for student in student_objects:
            data.append(student.to_string())
        return HttpResponse(json.dumps(Formatter.return_table_data(0, '', length, data)),
                            content_type="application/json")