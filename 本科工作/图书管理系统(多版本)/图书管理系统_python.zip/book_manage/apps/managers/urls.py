
# here put the import lib
from django.urls import path

from . import views


urlpatterns = [
    path('login/', views.login),
    path('system_manager/', views.system_manager),
    path('student_manager/', views.student_manager),
    path('book_manager/', views.book_manager),
    path('pwd/', views.pwd),
    path('add_manager/', views.add_manager),
    path('del_manager/', views.del_manager),
    path('edit_manager/',views.edit_manager),
    path('del_group_manager/',views.del_group_manager),
    path('upload_group_manager/',views.upload_group_manager),
    path('add_student/', views.add_student),
    path('del_student/', views.del_student),
    path('edit_student/', views.edit_student),
    path('del_group_student/',views.del_group_student),
    path('upload_group_student/',views.upload_group_student),
    path('del_book/', views.del_book),
    path('edit_book/', views.edit_book),
    path('del_group_book/',views.del_group_book),
    path('upload_group_book/',views.upload_group_book),
    path('search_book/',views.search_book),
    path('booklist/',views.booklist),
    path('search_student/',views.search_student),
    path('studentlist/',views.studentlist),
]
