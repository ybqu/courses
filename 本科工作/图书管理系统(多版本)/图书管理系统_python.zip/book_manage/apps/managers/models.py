
from django.db import models

# Create your models here.
class BmManager(models.Model):
    """ 管理员信息类 """
    id = models.AutoField(primary_key = True)
    username = models.CharField(max_length=20)
    name = models.CharField(max_length=255)
    password = models.CharField(max_length=255)
    role = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'bm_manager'

    def to_json(self):

        return {"id": self.id, "username": self.username, "password":self.password, "name": self.name, "role": self.role}

    def to_string(self):
        if self.role == 0:
            role_string = "系统管理员"
        elif self.role == 1:
            role_string = "学生管理员"
        elif self.role == 2:
            role_string = "图书管理员"
        passwd = "******"
        return {"id": self.id, "username": self.username, "password": passwd, "name": self.name, "role": role_string}

    # def role(self):
    #     return self.role