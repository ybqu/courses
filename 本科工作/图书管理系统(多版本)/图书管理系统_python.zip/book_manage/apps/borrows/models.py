#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@File    :   models.py
@Time    :   2019/11/23 16:57:05
@Author  :   Qu Yuanbin 
@Version :   1.0
@Contact :   2191002033@cnu.edu.cn
@License :   
@Desc    :   借阅 & 预约 APP
'''

# here put the import lib


# Create your models here.




from django.db import models
class BmBorrow(models.Model):
    """ 借阅信息类 """
    id = models.AutoField(primary_key = True)
    stu_no = models.CharField(max_length=10)
    book_no = models.CharField(max_length=6)
    borrow_date = models.DateTimeField()
    deadline = models.DateTimeField()
    return_date = models.DateTimeField(blank=True, null=True)
    is_return = models.IntegerField()
    is_renewal = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'bm_borrow'

    def to_json(self):
        """ 对象转换为 dict 返回 """
        self.borrow_date = self.borrow_date.strftime('%Y-%m-%d %H:%M')
        self.deadline = self.deadline.strftime('%Y-%m-%d %H:%M')
        self.return_date = self.return_date.strftime(
            '%Y-%m-%d %H:%M') if self.return_date else ''
        return {
            "id": self.id,
            "stu_no": self.stu_no,
            "book_no": self.book_no,
            "borrow_date": self.borrow_date,
            "deadline": self.deadline,
            "return_date": self.return_date,
            "is_return": self.is_return,
            "is_renewal": self.is_renewal
        }


class BmReservation(models.Model):
    """ 预约信息类 """
    id = models.AutoField(primary_key = True)
    stu_no = models.CharField(max_length=10)
    book_no = models.CharField(max_length=6)
    date = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'bm_reservation'

    def to_json(self):
        """ 对象转换为 dict 返回 """
        self.date = self.date.strftime('%Y-%m-%d %H:%M')

        return {
            "id": self.id,
            "stu_no": self.stu_no,
            "book_no": self.book_no,
            "date": self.date,
        }