from django.apps import AppConfig


class BorrowsConfig(AppConfig):
    name = 'borrows'
