#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@File    :   urls.py
@Time    :   2019/11/26 00:11:52
@Author  :   Quxiansen
@Version :   1.0
@Contact :   raogx.vip@hotmail.com
@License :   (C)Copyright 2017-2018, Liugroup-NLPR-CASIA
@Desc    :   图书相关页面　urls
'''

# here put the import lib
from django.urls import path, re_path

from . import views


urlpatterns = [
    re_path(r'^search$', views.search_booklist),
    re_path(r'^search/(.+)/$', views.search_book),
    path('new_book/', views.new_book),
    path('borrow/', views.borrow),
    path('reserve/', views.reserve),
    path('cancel_reserve/', views.cancel_reserve),
    path('renewal/', views.renewal),
    path('return/', views.return_book),
    path('comment/add/', views.comment_add),
]
