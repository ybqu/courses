#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@File    :   login.py
@Time    :   2019/11/23 19:24:56
@Author  :   Qu Yuanbin 
@Version :   1.0
@Contact :   2191002033@cnu.edu.cn
@License :   
@Desc    :   系统主页面
'''

# here put the import lib

import json
from django.shortcuts import render, redirect, HttpResponse
from utils.data import Formatter


def index(request):
    """ 渲染主页 """
    return render(request, 'index.html')


def redirect_to_index(request):
    """ 重定向到 index 页面 """
    return redirect('/index')


def logout(request):
    """ 退出登录响应 """
    print('sfdfadfasdfsa')
    if request.session.get('userinfo'):
        del request.session['userinfo']
    return HttpResponse(json.dumps(Formatter.return_data()))
