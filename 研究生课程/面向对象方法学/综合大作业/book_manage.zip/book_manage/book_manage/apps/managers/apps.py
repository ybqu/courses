from django.apps import AppConfig


class ManagersConfig(AppConfig):
    name = 'managers'
