#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@File    :   models.py
@Time    :   2019/11/19 23:36:48
@Author  :   Quxiansen
@Version :   1.0
@Contact :   raogx.vip@hotmail.com
@License :   (C)Copyright 2017-2018, Liugroup-NLPR-CASIA
@Desc    :   图书 APP
'''

# here put the import lib

from django.db import models


# Create your models here.
class BmBook(models.Model):
    """ 图书信息类 """
    no = models.CharField(primary_key=True, max_length=6)
    title = models.CharField(max_length=255)
    author = models.CharField(max_length=255)
    publisher = models.CharField(max_length=255)
    p_date = models.DateField()
    inventory = models.IntegerField()
    lend_num = models.IntegerField()
    borrow_num = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'bm_book'

    def to_json(self):
        """ 转换为json格式 """
        return {
            "no": self.no,
            "title": self.title,
            "author": self.author,
            "publisher": self.publisher,
            "p_date": str(self.p_date),
            "inventory": int(self.inventory),
            "lend_num": int(self.lend_num),
            "borrow_num": int(self.borrow_num)
        }

class BmComment(models.Model):
    """ 评论信息类 """
    id = models.AutoField(primary_key = True)
    stu_no = models.CharField(max_length=10)
    book_no = models.CharField(max_length=6)
    content = models.CharField(max_length=255)
    score = models.DecimalField(max_digits=2, decimal_places=1)
    date = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'bm_comment'

    def to_json(self):
        """ 转换为json格式 """
        self.date = self.date.strftime('%Y-%m-%d %H:%M')
        return {
            "id": self.id,
            "stu_no": self.stu_no,
            "book_no": self.book_no,
            "content": self.content,
            "score": float(self.score),
            "date": str(self.date),
        }
        