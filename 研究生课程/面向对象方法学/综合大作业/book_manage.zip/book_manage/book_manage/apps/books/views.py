#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@File    :   views.py
@Time    :   2019/11/26 00:12:49
@Author  :   Quxiansen
@Version :   1.0
@Contact :   raogx.vip@hotmail.com
@License :   (C)Copyright 2017-2018, Liugroup-NLPR-CASIA
@Desc    :   图书相关视图
'''

# here put the import lib
import json
from django.shortcuts import render, HttpResponse, redirect
from .models import BmBook, BmComment
from ..students.models import BmStudent
from ..borrows.models import BmBorrow, BmReservation
from utils.data import Formatter
from django.db.models import Q
from datetime import datetime, timedelta

# add urllib unquote
from urllib.parse import unquote


# Create your views here.
def search_booklist(request):
    """ 渲染图书查询界面 """
    if request.method == 'GET':
        info = request.GET.get('info')
        return render(request, 'book/booklist.html', {'cur_user': request.session.get('userinfo')['no'], 'search_info': info})
    if request.method == 'POST':
        option = int(request.POST.get('option', None))
        info = unquote(request.POST.get('info', None))
        page = int(request.POST.get('page', None))
        limit = int(request.POST.get('limit', None))

        if option == 0:  # 书名查询
            book_objects = BmBook.objects.filter(title__contains=info)[
                (limit * (page - 1)): (limit * page)]
            count = BmBook.objects.filter(title__contains=info).count()
        elif option == 1:  # 作者查询
            book_objects = BmBook.objects.filter(author__contains=info)[
                (limit * (page - 1)): (limit * page)]
            count = BmBook.objects.filter(author__contains=info).count()
        elif option == 2:  # 出版社查询
            book_objects = BmBook.objects.filter(publisher__contains=info)[
                (limit * (page - 1)): (limit * page)]
            count = BmBook.objects.filter(publisher__contains=info).count()

        data = []
        for book in book_objects:
            data.append(book.to_json())
        return HttpResponse(json.dumps(Formatter.return_table_data(0, '', count, data)), content_type="application/json")


def search_book(request, no):
    """ 渲染单本图书查询界面 """
    if request.method == 'GET':
        try:
            book_object = BmBook.objects.get(no=no)  # 查询图书信息
            book = book_object.to_json()
            book['borrowable'] = book['inventory'] - book['lend_num']
        except BmBook.DoesNotExist:
            book = {}
        finally:
            comment_objects = BmComment.objects.filter(book_no=no)

            # 可以改用多表联合查询 -- but 我不会。。。。
            comment_list = []
            for i, comment in enumerate(comment_objects):
                comment_list.append(comment.to_json())
                student_object = BmStudent.objects.get(no=comment.stu_no)
                comment_list[i]['stu_name'] = student_object.name

            return render(request, 'book/book.html', {
                'cur_user': request.session.get('userinfo')['no'], 'book': book, 'comment_list': comment_list})


def new_book(request):
    """ 渲染新书推荐界面 """
    if request.method == 'GET':
        return render(request, 'book/new_book.html', {'cur_user': request.session.get('userinfo')['no']})
    elif request.method == 'POST':
        book_objects = BmBook.objects.all().order_by("-p_date")[0: 14]

        books = []
        for book in book_objects:
            books.append(book.to_json())

        return HttpResponse(json.dumps(Formatter.return_table_data(0, '', len(books), books)))


def borrow(request):
    """ 处理图书借阅响应 """
    if request.method == 'POST':
        book_no = request.POST.get('book_no', None)

        borrowed_object = BmBorrow.objects.filter(Q(stu_no=request.session.get(
            'userinfo')['no']) & Q(book_no=book_no) & Q(is_return=0))
        


        if BmBorrow.objects.filter(Q(stu_no=request.session.get('userinfo')['no']) & Q(is_return=0)).count() == 10:
            code = 1  # 超过10本可借阅数量
        elif len(borrowed_object) != 0:
            code = 1  # 不可重复借阅
        else:
            # 修改图书信息
            book = BmBook.objects.get(no=book_no)
            book.lend_num += 1
            book.borrow_num += 1
            book.save()

            # 添加借阅信息
            BmBorrow.objects.create(
                stu_no=request.session.get('userinfo')['no'],
                book_no=book_no,
                borrow_date=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                deadline=(datetime.now()+timedelta(days=30)
                          ).strftime("%Y-%m-%d %H:%M:%S"),
                return_date=None,
                is_return=0,
                is_renewal=0
            )

            # 查询预约信息
            try:
                BmReservation.objects.get(
                    Q(stu_no=request.session.get('userinfo')['no']) & Q(book_no=book_no)).delete()
            except BmReservation.DoesNotExist:
                pass
            code = 0

        return HttpResponse(json.dumps(Formatter.return_data(code)))


def reserve(request):
    """ 处理图书预约响应 """
    if request.method == 'POST':
        book_no = request.POST.get('book_no', None)

        try:
            if BmReservation.objects.get(Q(stu_no=request.session.get('userinfo')['no']) & Q(book_no=book_no)):
                code = 1
        except BmReservation.DoesNotExist:
            code = 0
            # 添加预约信息
            BmReservation.objects.create(
                stu_no=request.session.get('userinfo')['no'],
                book_no=book_no,
                date=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            )

        return HttpResponse(json.dumps(Formatter.return_data(code)))


def cancel_reserve(request):
    """ 取消预约响应 """
    if request.method == 'POST':
        id = request.POST.get('id', None)

        try:
            BmReservation.objects.get(id=id).delete()
        except BmReservation.DoesNotExist:
            pass

        return HttpResponse(json.dumps(Formatter.return_data()))


def renewal(request):
    """ 处理图书续借响应 """
    if request.method == 'POST':
        id = request.POST.get('id', None)

        try:
            borrow_object = BmBorrow.objects.get(id=id)

            borrow_object.deadline = (
                borrow_object.deadline + timedelta(days=30)).strftime("%Y-%m-%d %H:%M:%S")
            borrow_object.is_renewal = 1

            borrow_object.save()

            code = 0
        except BmBorrow.DoesNotExist:
            code = 1

        return HttpResponse(json.dumps(Formatter.return_data(code)))


def return_book(request):
    """ 处理图书归还响应 """
    if request.method == 'POST':
        id = request.POST.get('id', None)
        book_no = request.POST.get('book_no', None)

        try:
            borrow = BmBorrow.objects.get(id=id)
            borrow.return_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            borrow.is_return = 1
            borrow.is_renewal = 0
            borrow.save()

            book = BmBook.objects.get(no=book_no)
            book.lend_num -= 1
            book.save()

            code = 0
        except:
            code = 1

        return HttpResponse(json.dumps(Formatter.return_data(code)))


def comment_add(request):
    """ 处理添加评论响应 """
    if request.method == 'POST':
        BmComment.objects.create(
            stu_no=request.session.get('userinfo')['no'],
            book_no=request.POST.get('book_no'),
            content=request.POST.get('content'),
            score=request.POST.get('score'),
            date=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        )

        return HttpResponse(json.dumps(Formatter.return_data()))
