#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@File    :   urls.py
@Time    :   2019/11/24 22:23:25
@Author  :   Quxiansen
@Version :   1.0
@Contact :   raogx.vip@hotmail.com
@License :   (C)Copyright 2017-2018, Liugroup-NLPR-CASIA
@Desc    :   学生相关页面 urls
'''

# here put the import lib
from django.urls import path

from . import views


urlpatterns = [
    path('login/', views.login),
    path('index/', views.index),
    path('new_pwd/', views.new_pwd),
    path('reserve_info/', views.reserve_info),
]
