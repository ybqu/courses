#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@File    :   views.py
@Time    :   2019/11/27 12:30:02
@Author  :   Qu Yuanbin
@Version :   1.0
@Contact :   2191002033@cnu.edu.cn
@License :
@Desc    :   None
'''

# here put the import lib
import json
from django.shortcuts import render, HttpResponse
from utils.data import Formatter
from django.db.models import Q
from apps.books.models import BmBook
from .models import BmBorrow
# Create your views here.


def borrow_info(request):
    """ 渲染学生借阅信息界面 """
    if request.method == 'GET':
        return render(request, 'student/borrow_info.html', {
            'cur_user': request.session.get('userinfo')['no'],
            'userinfo': request.session.get('userinfo')
            })
    elif request.method == 'POST':
        option = int(request.POST.get('option', None))

        if option == 0:  # 全部借阅信息
            borrow_objects = BmBorrow.objects.filter(
                stu_no=request.session.get('userinfo')['no'])
        elif option == 1:  # 借阅中
            borrow_objects = BmBorrow.objects.filter(
                Q(stu_no=request.session.get('userinfo')['no']) & Q(is_return=0))
        elif option == 2:  # 预约中
            pass
        elif option == 3:  # 已归还
            borrow_objects = BmBorrow.objects.filter(
                Q(stu_no=request.session.get('userinfo')['no']) & Q(is_return=1))

        borrow_infos = []
        for borrow in borrow_objects:
            borrow = borrow.to_json()
            try:
                book = BmBook.objects.get(no=borrow['book_no'])
                borrow['book_title'] = book.title
            except BmBook.DoesNotExist:
                borrow['book_title'] = ''
            finally:
                borrow_infos.append(borrow)

        return HttpResponse(json.dumps(Formatter.return_table_data(0, '', len(borrow_infos), borrow_infos)))

def borrow_order(request):
    """ 渲染借阅排行界面 """
    if request.method == 'GET':
        return render(request, 'book/borrow_order.html', {'cur_user': request.session.get('userinfo')['no']})
    elif request.method == 'POST':
        page = int(request.POST.get('page', None))
        limit = int(request.POST.get('limit', None))

        book_objects = BmBook.objects.all().order_by("-borrow_num")[(limit * (page - 1)) : (limit * page - 1)]
        
        books = []
        for book in book_objects:
            books.append(book.to_json())

        return HttpResponse(json.dumps(Formatter.return_table_data(0, '', len(books), books)))
