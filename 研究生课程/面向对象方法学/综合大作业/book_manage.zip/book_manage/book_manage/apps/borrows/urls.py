#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@File    :   urls.py
@Time    :   2019/11/27 12:29:16
@Author  :   Qu Yuanbin 
@Version :   1.0
@Contact :   2191002033@cnu.edu.cn
@License :   
@Desc    :   None
'''

# here put the import lib
from django.urls import path, re_path

from . import views


urlpatterns = [
    path('borrow_info/', views.borrow_info, name='borrowInfo'),
    path('borrow_order/', views.borrow_order),
]