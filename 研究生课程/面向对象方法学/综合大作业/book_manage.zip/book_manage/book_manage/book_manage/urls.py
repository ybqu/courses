#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@File    :   urls.py
@Time    :   2019/11/24 01:57:47
@Author  :   Quxiansen
@Version :   1.0
@Contact :   raogx.vip@hotmail.com
@License :   (C)Copyright 2017-2018, Liugroup-NLPR-CASIA
@Desc    :   设置 urls
'''

# here put the import lib
from django.urls import path, include

from . import views


urlpatterns = [
    path('', views.redirect_to_index),  # 将页面重定向到 index
    path('index/', views.index),
    path('logout/', views.logout),
    path('student/', include('apps.students.urls')),
    path('student/', include('apps.borrows.urls')),
    path('manager/', include('apps.managers.urls')),
    path('book/', include('apps.books.urls')),
    path('book/', include('apps.borrows.urls')),
]
