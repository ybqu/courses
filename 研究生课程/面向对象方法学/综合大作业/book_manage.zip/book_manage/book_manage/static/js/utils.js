//自定义 URL 工具类

var UrlUtils = {
    // 获取 URL 参数
    getQueryVariable: (variable) => {
        var query = window.location.search.substring(1)
        var vars = query.split("&")

        for (var i = 0; i < vars.length; i++) {
            var pair = vars[i].split("=")
            if (pair[0] == variable)
                return pair[1]
        }
        return false
    }
}

var DataUtils = {
    // 获取当前时间
    getNowDate: () => {
        var date = new Date()
        var sign1 = "-"
        var sign2 = ":"
        var year = date.getFullYear() // 年
        var month = date.getMonth() + 1 // 月
        var day = date.getDate() // 日
        var hour = date.getHours() // 时
        var minutes = date.getMinutes() // 分
        // 给一位数数据前面加 “0”
        if (month >= 1 && month <= 9) {
            month = "0" + month
        }
        if (day >= 0 && day <= 9) {
            day = "0" + day
        }
        if (hour >= 0 && hour <= 9) {
            hour = "0" + hour
        }
        if (minutes >= 0 && minutes <= 9) {
            minutes = "0" + minutes
        }
        var currentdate = year + sign1 + month + sign1 + day + " " + hour + sign2 + minutes
        return currentdate
    }
}
