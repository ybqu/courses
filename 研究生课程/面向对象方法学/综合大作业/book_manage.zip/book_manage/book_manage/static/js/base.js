/*
 * @Descripttion: 
 * @version: 
 * @Author: quxiansen
 * @Date: 2019-11-29 09:29:30
 * @LastEditors: quxiansen
 * @LastEditTime: 2019-11-29 10:14:05
 */
var logout = function () {
    // 用户退出登录函数
    $.ajax({
        url: '/logout/',
        type: 'post',
        dataType: 'json',
        data: { csrfmiddlewaretoken: $('[name="csrfmiddlewaretoken"]').val() },
        success: function (result) {
            layer.msg('退出登录', { icon: 1, time: 1000 })
            window.location.href = '/'
        }
    })
}

 // 图书借阅函数
 window.borrow = function (book_no) {
    $.ajax({
        url: '/book/borrow/',
        type: 'POST',
        data: {
            csrfmiddlewaretoken: $('[name="csrfmiddlewaretoken"]').val(),
            book_no: book_no
        },
        dataType: 'json',
        success: function (result) {
            if (result.code === 0) {
                layer.msg('借阅成功, 1秒后跳转...', { icon: 1 })
                // table.reload('tab')
                setTimeout(function () {
                    window.location.href = '/student/borrow_info'
                }, 1000)
            }
            else {
                layer.msg('借阅超过10本或重复借阅', { icon: 2 })
            }
        }
    })
}

 // 图书预约函数
 window.reserve = function (book_no) {
    $.ajax({
        url: '/book/reserve/',
        type: 'POST',
        data: {
            csrfmiddlewaretoken: $('[name="csrfmiddlewaretoken"]').val(),
            book_no: book_no
        },
        dataType: 'json',
        success: function (result) {
            if (result.code === 0) {
                layer.msg('预约成功, 1秒后跳转...', { icon: 1 })
                // table.reload('tab')
                setTimeout(function () {
                    window.location.href = '/student/borrow_info'
                }, 1000)
            } else {
                layer.msg('重复预约', { icon: 2 })
            }
        }
    })
}
