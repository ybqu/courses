# 图书管理系统 -- Book_Manage

## 目录结构

+ **book_manage**  --  项目名称

    + **系统设计**  --  系统相关文件
        + [功能接口设计.md](./系统设计/功能接口设计.md)
        + [功能设计.md](./系统设计/功能设计.md)
        + [数据库设计.md](./系统设计/数据库设计.md)
+ **作业要求**
        + [2019研究生课程作业（图书管理）](./作业要求/2019研究生课程作业（图书管理）.pdf)
    + **assets**  --  存放资源文件
+ **book_manage**  --  项目文件
    + **apps** 
        + **books** -- 图书信息 app
        + **borrows** -- 借阅信息 app
        + **comments** -- 评论信息 app
        + **managers** -- 管理员信息 app
        + **students** -- 学生信息 app
    + **book_manage**  --  项目配置目录
        + **static**
            + **css**  --  样式目录
            + **images**  --  图片资源目录
            + **js**  --  JavaScript 脚本目录
            + **layui**  --  前端框架目录
        + **templates**  -- 页面 ``.html`` 文件
            + **_layouts**  --  ``base.html`` 模板文件目录
            + **_partials**  --  部件目录（header）
        + **utils**  --  工具目录
        + **manage.py**  --  项目入口
    + [README.md](./README.md)

## -- author

+ 午康俊
+ 屈原斌